#ifndef PROJ_65_SETTINGS_H
#define PROJ_65_SETTINGS_H

#include<iostream>
#include<vector>
#include<map>

using namespace std;

const int WIDTH = 960, HEIGHT = 800;
const int GAME_WIDTH = 720;
const double DELAY = 8;
extern int ballsInARow;
extern double ballDiameter;
extern int ballRows;
extern char *FONT;
extern string STATE;
extern int THEME;
extern string MODE;
extern string USER_NAME;

// user variables
struct USER_STRUCT {
    string username;
    int highestInfScore;
    int highestTimeScore;
    int highestCasualScore;
    int bombs = 3;
    int lasers = 3;
};
extern vector<USER_STRUCT> usersData;
extern USER_STRUCT *CURRENT_USER;
extern int USER_SCORE;

// game variables
extern vector<double> fillProbability;
extern vector<double> spreadProbability;
extern vector<double> lockProbability;
extern vector<double> color2Probability;
const double FALLEN_BALL_SPEED_Y = 10;
extern double BALL_SPACE_APPROACH_SPEED_Y;
extern double REMAINING_TIME;
extern bool CANNON_LASER_SHOT;
extern bool BOMB_SHOT;
extern bool stopApproach;
extern double slowMotion;
extern bool TIME_EFFECT_APPLIED;

// -----------------------------------------

extern int SOUNDMODE;
extern int soundsfx;
extern int soundmusic;
extern int backsoundmusic;
extern int backsoundsfx;
extern bool adjustingm;
extern bool adjustings;
extern int R, G, B;
extern string BACKSTATE;
extern bool entered[10];

#endif //PROJ_65_SETTINGS_H
