#ifndef PROJ_65_GAMEOBJECTS_H
#define PROJ_65_GAMEOBJECTS_H

#include "settings.h"

using namespace std;

// legacy ballSpace
//struct BallCell {
//    string textureCode = "00";
//    bool locked = false;
//    vector<BallCell *> colorNeighbors = {};
//    vector<BallCell *> lockNeighbors = {};
//    double x = 0;
//    double y = 0;
//    int inRow = 0;
//    int inCol = 0;
//    double speedX = 0;
//    double speedY = 0.1;
//};

struct BallCell {
    double topLeftX;
    double topLeftY;
    int row;
    int col;
    string status = "empty"; // "containing", "pop", "fallen", "justUnlocked", "empty"
    bool locked = false;
    bool timeEffect = false;
    bool fallen = false; // it's always false in the main ballSpace and this is just an auxiliary variable used in the copy of ballSpace
    int color1 = 0;
    int color2 = 0;
    double speedX = 0;
    double speedY = BALL_SPACE_APPROACH_SPEED_Y;
};

struct UnderCannon {
    double height = 211.0 / 3.0;
    double width = 232.0 / 3.0;
    double centerX = (double) GAME_WIDTH / 2;
    double centerY = (double) HEIGHT - height;
};

struct Cannon {
    double height = 295.0 / 2.8;
    double width = 126.0 / 2.8;
    double centerX = UnderCannon().centerX;
    double centerY = UnderCannon().centerY;
    double angle = 0;
};


struct ActionBall {
    double height = ballDiameter;
    double width = ballDiameter;
    double centerX;
    double centerY;
    double speedX = 0;
    double speedY = 0;
    double animationLevel = 0; // only used for pop balls
    double maxAnimationLevel = 0; // only used for pop balls
    int color = 0;
    int color2 = 0;
    string type;
};

#endif //PROJ_65_GAMEOBJECTS_H
