#include "TextRenderer.h"
#include <iostream>

TextRenderer::TextRenderer() {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "SDL initialization failed: " << SDL_GetError() << std::endl;
        // Handle initialization failure as needed
    }

    if (TTF_Init() < 0) {
        std::cerr << "SDL_TTF initialization failed: " << TTF_GetError() << std::endl;
        // Handle initialization failure as needed
    }
}

TextRenderer::~TextRenderer() {
    for (auto &pair: fonts) {
        TTF_CloseFont(pair.second);
    }

    TTF_Quit();
    SDL_Quit();
}

bool TextRenderer::loadFont(const std::string &fontPath, int fontSize, const std::string &fontKey) {
    TTF_Font *font = TTF_OpenFont(fontPath.c_str(), fontSize);
    if (!font) {
        std::cerr << "Failed to load font: " << TTF_GetError() << std::endl;
        return false;
    }

    fonts[fontKey] = font;
    return true;
}

void TextRenderer::renderText(SDL_Renderer *renderer, const std::string &text, const std::string &fontKey, int x, int y,
                              int r, int g, int b) {
    auto it = fonts.find(fontKey);
    if (it == fonts.end()) {
        std::cerr << "Font not found: " << fontKey << std::endl;
        return;
    }

    TTF_Font *font = it->second;

    SDL_Color textColor = {static_cast<Uint8>(r), static_cast<Uint8>(g), static_cast<Uint8>(b)};

    SDL_Surface *surface = TTF_RenderText_Solid(font, text.c_str(), textColor);
    if (!surface) {
        std::cerr << "Failed to render text: " << TTF_GetError() << std::endl;
        // Handle rendering failure as needed
        return;
    }

    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        std::cerr << "Failed to create texture: " << SDL_GetError() << std::endl;
        // Handle texture creation failure as needed
    } else {
        SDL_Rect destinationRect = {x, y, surface->w, surface->h};
        SDL_RenderCopy(renderer, texture, nullptr, &destinationRect);

        SDL_DestroyTexture(texture);
    }

    SDL_FreeSurface(surface);
}
