#include "SoundManager.h"
#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

//
//SoundManager::SoundManager() {
//    if (SDL_Init(SDL_INIT_AUDIO) < 0) {
//        std::cerr << "SDL initialization failed: " << SDL_GetError() << std::endl;
//        // Handle initialization failure as needed
//    }
//
//    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096) < 0) {
//        std::cerr << "SDL Mixer initialization failed: " << Mix_GetError() << std::endl;
//        // Handle initialization failure as needed
//    }
//}
//
//SoundManager::~SoundManager() {
//    for (auto &pair: sounds) {
//        Mix_FreeChunk(pair.second);
//    }
//
//    Mix_CloseAudio();
//    SDL_Quit();
//}
//
//bool SoundManager::loadSound(const char *filePath, const std::string &soundName) {
//    Mix_Chunk *sound = Mix_LoadWAV(filePath);
//    if (!sound) {
//        std::cerr << "Failed to load sound: " << Mix_GetError() << std::endl;
//        return false;
//    }
//
//    sounds[soundName] = sound;
//    return true;
//}
//
//void SoundManager::playSound(const std::string &soundName) {
//    Mix_PlayChannel(-1, sounds[soundName], 0);
//}
//
//void SoundManager::stopSound(const std::string &soundName) {
//    int channel = Mix_Playing(-1);
//    while (channel != -1) {
//        if (Mix_GetChunk(channel) == sounds[soundName]) {
//            Mix_HaltChannel(channel);
//        }
//        channel = Mix_Playing(-1);
//    }
//}
//
//void SoundManager::setVolume(const std::string &soundName, int volume) {
//    Mix_VolumeChunk(sounds[soundName], volume);
//}
SoundManager::SoundManager() {
    if (SDL_Init(SDL_INIT_AUDIO) < 0) {
        std::cerr << "SDL initialization failed: " << SDL_GetError() << std::endl;
        // Handle initialization failure as needed
    }

    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096) < 0) {
        std::cerr << "SDL Mixer initialization failed: " << Mix_GetError() << std::endl;
        // Handle initialization failure as needed
    }
}

SoundManager::~SoundManager() {
    for (auto &pair: sounds) {
        Mix_FreeChunk(pair.second.sound);
    }

    Mix_CloseAudio();
    SDL_Quit();
}

bool SoundManager::loadSound(const char *filePath, const std::string &soundName) {
    Mix_Chunk *sound = Mix_LoadWAV(filePath);
    if (!sound) {
        std::cerr << "Failed to load sound: " << Mix_GetError() << std::endl;
        return false;
    }

    sounds[soundName] = {sound, -1};  // Initialize channel to -1
    return true;
}

void SoundManager::playSound(const std::string &soundName) {
    SoundInfo &soundInfo = sounds[soundName];
    soundInfo.channel = Mix_PlayChannel(-1, soundInfo.sound, 0);
}

void SoundManager::stopSound(const std::string &soundName) {
    SoundInfo &soundInfo = sounds[soundName];
    if (soundInfo.channel != -1) {
        Mix_HaltChannel(soundInfo.channel);
        soundInfo.channel = -1;  // Reset channel to -1
    }
}

void SoundManager::setVolume(const std::string &soundName, int volume) {
    Mix_VolumeChunk(sounds[soundName].sound, volume);
}
