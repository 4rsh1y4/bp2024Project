#include"./settings.h"

int ballsInARow = 16;
double ballDiameter = (double) GAME_WIDTH / (ballsInARow + .5);
int ballRows = ((int) (HEIGHT / ballDiameter / 2) % 2 == 0) ? (int) (HEIGHT / ballDiameter / 2) :
               (int) (HEIGHT / ballDiameter / 2) + 1 + 4;
char *FONT = "E:\\cpp\\Proj_65\\assets\\vazir.ttf";

int THEME = 0;
string MODE = "preGame"; // "casual", "time", "inf"
string STATE = "mainMenu"; // "mainMenu", "game", "gameOver", "won", "pauseMenu", "preGame"

// user variables
extern string USER_NAME = "";
USER_STRUCT *CURRENT_USER = nullptr;

// game variables
vector<double> fillProbability = {1, 2};
vector<double> spreadProbability = {1, 15};
vector<double> lockProbability = {50, 5};
vector<double> color2Probability = {6, 2};
int USER_SCORE = 0;
double BALL_SPACE_APPROACH_SPEED_Y = 0.1;
double REMAINING_TIME = 60;
bool CANNON_LASER_SHOT = false;
bool BOMB_SHOT = false;
bool stopApproach = false;
double slowMotion = 0;
bool TIME_EFFECT_APPLIED = false;

// ---------------------------------------

int SOUNDMODE = 0;
int soundmusic = 100;
int soundsfx = 100;
int backsoundsfx = 100;
int backsoundmusic = 100;
string BACKSTATE = "mainMenu";
bool adjustingm = false;
bool adjustings = false;
int R, G, B;
bool entered[10] = {0};
