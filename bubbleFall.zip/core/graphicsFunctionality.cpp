#include"./graphicsFunctionality.h"

bool loadAssets(TextureManager *textureManager, SoundManager *soundManager, TextRenderer *textRenderer) {
    textureManager->loadTexture("../assets/normallight01.png", "ball1");
    textureManager->loadTexture("../assets/normallight02.png", "ball2");
    textureManager->loadTexture("../assets/normallight03.png", "ball3");
    textureManager->loadTexture("../assets/normallight04.png", "ball4");
    textureManager->loadTexture("../assets/normallight05.png", "ball5");
    textureManager->loadTexture("../assets/normallight06.png", "ball6");
    textureManager->loadTexture("../assets/wild.png", "ball7");
    textureManager->loadTexture("../assets/wildBomb.png", "ball8");
    textureManager->loadTexture("../assets/halflight01.png", "hball1");
    textureManager->loadTexture("../assets/halflight02.png", "hball2");
    textureManager->loadTexture("../assets/halflight03.png", "hball3");
    textureManager->loadTexture("../assets/halflight04.png", "hball4");
    textureManager->loadTexture("../assets/halflight05.png", "hball5");
    textureManager->loadTexture("../assets/lightStave.png", "cannon");
    textureManager->loadTexture("../assets/pop/03.png", "pop0");
    textureManager->loadTexture("../assets/pop/04.png", "pop1");
    textureManager->loadTexture("../assets/pop/05.png", "pop2");
    textureManager->loadTexture("../assets/pop/06.png", "pop3");
    textureManager->loadTexture("../assets/pop/07.png", "pop4");
    textureManager->loadTexture("../assets/pop/08.png", "pop5");
    textureManager->loadTexture("../assets/pop/09.png", "pop6");
    textureManager->loadTexture("../assets/pop/10.png", "pop7");
    textureManager->loadTexture("../assets/pop/11.png", "pop8");
    textureManager->loadTexture("../assets/pop/12.png", "pop9");
    textureManager->loadTexture("../assets/pop/13.png", "pop10");
    textureManager->loadTexture("../assets/Tower.png", "tower");
    textureManager->loadTexture("../assets/lock.png", "lock");
    textureManager->loadTexture("../assets/bomb.png", "bomb");
    textureManager->loadTexture("../assets/time.png", "time");
    textureManager->loadTexture("../assets/lightning.png", "lightning");
    textureManager->loadTexture("../assets/ui/panel.png", "panel");
    soundManager->loadSound("../assets/collision.wav", "collision");
    soundManager->loadSound("../assets/theme.wav", "theme");
    textRenderer->loadFont("../assets/vazir.ttf", 24, "vazir24");
    textRenderer->loadFont("../assets/vazir.ttf", 16, "vazir16");
    textRenderer->loadFont("../assets/vazir.ttf", 9, "vazir8");
    soundManager->loadSound("../assets/arcade1.wav", "arcade1");
    soundManager->loadSound("../assets/arcade2.wav", "arcade2");
    soundManager->loadSound("../assets/arcade3.wav", "arcade3");
    soundManager->loadSound("../assets/click.wav", "click");
 
    soundManager->loadSound("../assets/yip.wav", "yip");
    soundManager->loadSound("../assets/byebye.wav", "byebye");
    soundManager->loadSound("../assets/wompwomp.wav", "Lsound");
    textureManager->loadTexture("../assets/menubackground1.png", "background1");
    textureManager->loadTexture("../assets/menubackground2.png", "background2");
    textureManager->loadTexture("../assets/menubackground3.png", "background3");
    textureManager->loadTexture("../assets/bouncing-balls.png", "bouncingBalls");
    textureManager->loadTexture("../assets/menuNewGame.png", "newGame");
    textureManager->loadTexture("../assets/menuNewGamed.png", "newGamed");
    textureManager->loadTexture("../assets/menusettings.png", "menuSettings");
    textureManager->loadTexture("../assets/menusettingsd.png", "menuSettingsd");
    textureManager->loadTexture("../assets/high.png", "highScore");
    textureManager->loadTexture("../assets/highd.png", "highScored");
    textureManager->loadTexture("../assets/menuquit.png", "menuQuit");
    textureManager->loadTexture("../assets/menuquitd.png", "menuQuitd");
    textureManager->loadTexture("../assets/NGnormalmode.png", "normalMode");
    textureManager->loadTexture("../assets/NGracemode.png", "raceMode");
    textureManager->loadTexture("../assets/NGinfinitemode.png", "infiniteMode");
    textureManager->loadTexture("../assets/back.png", "menuBack");
    textureManager->loadTexture("../assets/backd.png", "menuBackd");
    textureManager->loadTexture("../assets/theme.png", "theme");
    textureManager->loadTexture("../assets/mute.png", "mute");
    textureManager->loadTexture("../assets/unmute.png", "unmute");
    textureManager->loadTexture("../assets/halloffame.png", "hof");     //changed
    textRenderer->loadFont("../assets/bahnschrift.ttf", 16, "bahnschrift16");
    textRenderer->loadFont("../assets/bahnschrift.ttf", 20, "bahnschrift20");
    textRenderer->loadFont("../assets/bahnschrift.ttf", 24, "bahnschrift24");
    textRenderer->loadFont("../assets/bahnschrift.ttf", 28, "bahnschrift28");
    textRenderer->loadFont("../assets/bahnschrift.ttf", 32, "bahnschrift32");

}

void updateBallSpace(vector<vector<BallCell>> *ballSpace, TextureManager *textureManager, SDL_Renderer *renderer,
                     int circleRGBA(SDL_Renderer *renderer, Sint16 x, Sint16 y, Sint16 rad, Uint8 r, Uint8 g, Uint8 b,
                                    Uint8 a), TextRenderer *textRenderer) {
    for (int row = (*ballSpace).size() - 1; row >= 0; row--) {
        for (int col = 0; col < (*ballSpace)[row].size(); col++) {
            BallCell *currentBallCell = &(*ballSpace)[row][col];
            // update graphics
            textureManager->draw(textureCode("ball", currentBallCell->color1), (int) currentBallCell->topLeftX,
                                 (int) currentBallCell->topLeftY,
                                 (int) ballDiameter,
                                 (int) ballDiameter);
            textureManager->draw(textureCode("hball", currentBallCell->color2), (int) currentBallCell->topLeftX,
                                 (int) currentBallCell->topLeftY,
                                 (int) ballDiameter,
                                 (int) ballDiameter);
            if (currentBallCell->locked) {
                textureManager->draw("lock", (int) currentBallCell->topLeftX + 9,
                                     (int) currentBallCell->topLeftY + 9,
                                     (int) ballDiameter - 18,
                                     (int) ballDiameter - 18);
            }
            if (currentBallCell->timeEffect) {
                textureManager->draw("time", (int) currentBallCell->topLeftX + 5,
                                     (int) currentBallCell->topLeftY + 5,
                                     (int) ballDiameter - 10,
                                     (int) ballDiameter - 10);
            }
            //debug code start
//            circleRGBA(renderer, currentBallCell->topLeftX + ballDiameter / 2,
//                       currentBallCell->topLeftY - currentBallCell->speedY + ballDiameter / 2, ballDiameter / 2, 0, 0,
//                       0, 255);
//            string position = to_string(currentBallCell->row) + ":" + to_string(currentBallCell->col);
//            string boolStat = "lo:" + to_string(currentBallCell->locked) + " fa:" + to_string(currentBallCell->fallen);
//            textRenderer->renderText(renderer, position.c_str(), "vazir8", currentBallCell->topLeftX + ballDiameter / 4,
//                                     currentBallCell->topLeftY + 3, 0, 0, 0);
//            textRenderer->renderText(renderer, currentBallCell->status.c_str(), "vazir8", currentBallCell->topLeftX + 3,
//                                     currentBallCell->topLeftY + 12, 0, 0, 0);
//            textRenderer->renderText(renderer, boolStat.c_str(), "vazir8", currentBallCell->topLeftX + 3,
//                                     currentBallCell->topLeftY + 24, 0, 0, 0);
            //debug code end
            // update properties
            if (slowMotion <= 0 && !stopApproach) {
                currentBallCell->topLeftY += BALL_SPACE_APPROACH_SPEED_Y;
            } else if (slowMotion > 0) {
                currentBallCell->topLeftY += BALL_SPACE_APPROACH_SPEED_Y / 2;
                slowMotion -= 0.101;
                cout << "slow motion: " << slowMotion;
            }
        }
    }
}

void updateCannonBalls(vector<ActionBall> *cannonBalls, Cannon *cannon,
                       TextureManager *textureManager) {
    for (ActionBall &cannonBall: *cannonBalls) {
        cannonBall.centerX =
                UnderCannon().centerX +
                ((37.0 / 295.0 * cannon->height + ballDiameter) * cos(angleToRad(cannon->angle - 90)));
        cannonBall.centerY =
                UnderCannon().centerY -
                ((37.0 / 295.0 * cannon->height + ballDiameter) * sin(-angleToRad(cannon->angle - 90)));
        cannonBall.speedX = ballDiameter * 5 / 6 * cos(angleToRad(cannon->angle - 90));
        cannonBall.speedY = ballDiameter * 5 / 6 * sin(angleToRad(cannon->angle - 90));
    }
    if ((*cannonBalls).size() != 0) {
        textureManager->draw(textureCode("ball", (*cannonBalls)[0].color),
                             topLeftOfTexture((*cannonBalls)[0].centerX,
                                              (*cannonBalls)[0].width)[0],
                             topLeftOfTexture(0, 0, (*cannonBalls)[0].centerY,
                                              (*cannonBalls)[0].height)[1],
                             (*cannonBalls)[0].width,
                             (*cannonBalls)[0].height);
    }
}

void updateShotBalls(vector<ActionBall> *shotBalls,
                     TextureManager *textureManager) {
    for (ActionBall &shotBall: *shotBalls) {
        if (shotBall.centerX + shotBall.speedX >= WIDTH || shotBall.centerX + shotBall.speedX <= 0) {
            shotBall.speedX *= -1;
        }
        shotBall.centerX += shotBall.speedX;
        shotBall.centerY += shotBall.speedY;
        textureManager->draw(textureCode("ball", shotBall.color),
                             topLeftOfTexture(shotBall.centerX,
                                              shotBall.width)[0],
                             topLeftOfTexture(0, 0, shotBall.centerY,
                                              shotBall.height)[1],
                             shotBall.width,
                             shotBall.height);
    }
}

void updateFallenBalls(vector<ActionBall> *fallenBalls,
                       TextureManager *textureManager) {
    for (ActionBall &fallenBall: *fallenBalls) {
        fallenBall.centerX += fallenBall.speedX;
        fallenBall.centerY += fallenBall.speedY;
        textureManager->draw(textureCode("ball", fallenBall.color),
                             fallenBall.centerX -
                             fallenBall.width / 2,
                             fallenBall.centerY -
                             fallenBall.height / 2,
                             fallenBall.width,
                             fallenBall.height);
        textureManager->draw(textureCode("hball", fallenBall.color2),
                             topLeftOfTexture(fallenBall.centerX,
                                              fallenBall.width)[0],
                             topLeftOfTexture(0, 0, fallenBall.centerY,
                                              fallenBall.height)[1],
                             fallenBall.width,
                             fallenBall.height);
    }
}

void updatePopBalls(vector<ActionBall> *popBalls,
                    TextureManager *textureManager) {
    for (ActionBall &popBall: *popBalls) {
        popBall.centerX += popBall.speedX;
        popBall.centerY += popBall.speedY;
        textureManager->draw(textureCode("pop", int(popBall.animationLevel)),
                             popBall.centerX -
                             popBall.width / 2,
                             popBall.centerY -
                             popBall.height / 2,
                             popBall.width,
                             popBall.height);
    }
}

void drawLaser(SDL_Renderer *renderer, vector<vector<double>> *laserEndPoints,
               int thickLineRGBA(SDL_Renderer *renderer, Sint16 x1, Sint16 y1, Sint16 x2, Sint16 y2, Uint8 width,
                                 Uint8 r, Uint8 g, Uint8 b, Uint8 a), bool laserShot) {
    sort((*laserEndPoints).begin(), (*laserEndPoints).end(), [](const auto &row1, const auto &row2) {
        // Assuming column 1 is at index 1 (0-indexed)
        return row1[1] > row2[1];
    });
    if (!laserShot) {
//        vector<vector<double>> selectedPointsToRender;
//        for (int i = 1; i < (*laserEndPoints).size(); i++) {
//            if ((*laserEndPoints)[i][0] == WIDTH || (*laserEndPoints)[i][0] == 0) {
//                selectedPointsToRender.push_back({(*laserEndPoints)[i][0], (*laserEndPoints)[i][1]});
//            }
//            if ((*laserEndPoints)[i][2] == 1) {
//                selectedPointsToRender.push_back({(*laserEndPoints)[i][0], (*laserEndPoints)[i][1]});
//                break;
//            }
//        }
//        selectedPointsToRender.insert(selectedPointsToRender.begin(), {(*laserEndPoints)[0][0], (*laserEndPoints)[0][1]});
//        for (int i = 1; selectedPointsToRender.size() > 1 && i < selectedPointsToRender.size(); i++) {
//            thickLineRGBA(renderer, selectedPointsToRender[i - 1][0], selectedPointsToRender[i - 1][1],
//                          selectedPointsToRender[i][0],
//                          selectedPointsToRender[i][1], ballDiameter / 2, 255, 0, 0, 255);
//        }
        for (int i = 1;
             (*laserEndPoints).size() > 1 && i < (*laserEndPoints).size() && (*laserEndPoints)[i - 1][2] == 0; i++) {
            thickLineRGBA(renderer, (*laserEndPoints)[i - 1][0], (*laserEndPoints)[i - 1][1], (*laserEndPoints)[i][0],
                          (*laserEndPoints)[i][1], ballDiameter / 2, 255, 0, 0, 255);
        }
    } else if (laserShot) {
        for (int i = 1; (*laserEndPoints).size() > 1 && i < (*laserEndPoints).size(); i++) {
            thickLineRGBA(renderer, (*laserEndPoints)[i - 1][0], (*laserEndPoints)[i - 1][1], (*laserEndPoints)[i][0],
                          (*laserEndPoints)[i][1], ballDiameter, 255, 0, 0, 80);
        }
    }
    (*laserEndPoints).erase((*laserEndPoints).begin(), (*laserEndPoints).end());
}

