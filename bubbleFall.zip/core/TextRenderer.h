#ifndef PROJ_65_TEXTRENDERER_H
#define PROJ_65_TEXTRENDERER_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <unordered_map>
#include <string>

class TextRenderer {
public:
    TextRenderer();

    ~TextRenderer();

    bool loadFont(const std::string &fontPath, int fontSize, const std::string &fontKey);

    void
    renderText(SDL_Renderer *renderer, const std::string &text, const std::string &fontKey, int x, int y, int r, int g,
               int b);

private:
    std::unordered_map<std::string, TTF_Font *> fonts;
};

#endif //PROJ_65_TEXTRENDERER_H
