#include"./utilities.h"

void saveDataToCSV(const vector<USER_STRUCT> &data, const string &filename) {
    std::ofstream file(filename);
    if (file.is_open()) {
        file << "Username,HighestInfScore,HighestTimeScore,HighestCasualScore,Bombs,Lasers\n";
        for (const auto &user: data) {
            file << user.username << "," << user.highestInfScore << ","
                 << user.highestTimeScore << "," << user.highestCasualScore << ","
                 << user.bombs << "," << user.lasers << "\n";
        }
        file.close();
        std::cout << "Data saved to " << filename << " successfully.\n";
    } else {
        std::cerr << "Error opening file: " << filename << "\n";
    }
}

vector<USER_STRUCT> loadDataFromCSV(const string &filename) {
    std::vector<USER_STRUCT> data;
    std::ifstream file(filename);
    if (file.is_open()) {
        std::string line;

        // Skip header
        std::getline(file, line);

        while (std::getline(file, line)) {
            std::istringstream iss(line);
            std::string token;

            USER_STRUCT user;

            // Read CSV values
            std::getline(iss, user.username, ',');
            std::getline(iss, token, ',');
            user.highestInfScore = std::stoi(token);
            std::getline(iss, token, ',');
            user.highestTimeScore = std::stoi(token);
            std::getline(iss, token, ',');
            user.highestCasualScore = std::stoi(token);
            std::getline(iss, token, ',');
            user.bombs = std::stoi(token);
            std::getline(iss, token, ',');
            user.lasers = std::stoi(token);

            data.push_back(user);
        }

        file.close();
        std::cout << "Data loaded from " << filename << " successfully.\n";
    } else {
        std::cerr << "Error opening file: " << filename << "\n";
    }

    return data;
}

double randomDouble(double max) {
    static random_device random;
    static mt19937 gen(random());
    uniform_real_distribution<double> dist(0.0, max);
    return dist(gen);
}

double pseudoRandomDouble(double max) {
    static bool seeded = false;
    if (!seeded) {
        srand(static_cast<unsigned int>(time(nullptr)));
        seeded = true;
    }
    int generatedRandomNumber = rand();
    generatedRandomNumber %= static_cast<int>(max * 1e3);
    generatedRandomNumber /= 1e3;

    return static_cast<double>(generatedRandomNumber);
}


int randomSelectionBasedOnProbability(vector<double> probabilities, bool inverse) {
    if (inverse) {
        for (double probability: probabilities) {
            probability = 1 / probability;
        }
    }
    double sum = 0;
    int itemsCount = 0;
    for (double probability: probabilities) {
        sum += probability;
        itemsCount++;
    }
    if (sum <= 0) {
        cout << "no probabilities possible for sum=" << sum << " : ";
        for (double probability: probabilities) {
            cout << probability << " ";
        }
        return -1;
    }
    // both random generators have different biases, so we choose between them randomly to have less bias
    double whichRandomFunction = pseudoRandomDouble(2);
    double selection;
    if (whichRandomFunction >= .8) {
        selection = randomDouble(sum);
    } else {
        selection = pseudoRandomDouble(sum);
    }
    sum = 0;
    for (int i = 0; i < itemsCount; i++) {
        sum += probabilities[i];
        if (selection < sum) {
            return i;
        }
    }
}

bool haveTheSameColor(BallCell *cell1, BallCell *cell2) {
//    if (cell1->color1 == cell2->color1 || (cell1->color1 == cell2->color2 && cell2->color2 != 0) ||
//        (cell1->color2 == cell2->color1 && cell1->color2 != 0) ||
//        (cell1->color2 == cell2->color2 && cell1->color2 != 0 && cell2->color2 != 0)) {
//        return true;
//    }
    if (cell1->color1 == cell2->color1 || (cell1->color1 == cell2->color2 && cell2->color2 != 0) ||
        (cell1->color2 == cell2->color1 && cell1->color2 != 0) ||
        (cell1->color2 == cell2->color2 && cell1->color2 != 0 && cell2->color2 != 0) || cell1->color1 == 7 ||
        cell2->color1 == 7) {
        return true;
    }
    return false;
}


vector<BallCell *> returnNeighbors(vector<vector<BallCell>> *ballSpace, int row, int col) {
    vector<BallCell *> neighbors;
    int maxRows = (*ballSpace).size();
    for (int neighbor = 0; neighbor < 6; neighbor++) {
        if (row % 2 == 0) {
            switch (neighbor) {
                case 0:
                    if ((row + 1) < maxRows) {
                        neighbors.push_back(&(*ballSpace)[row + 1][col]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 1:
                    if ((row + 1) < maxRows && (col + 1) < ballsInARow) {
                        neighbors.push_back(&(*ballSpace)[row + 1][col + 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 2:
                    if ((col + 1) < ballsInARow) {
                        neighbors.push_back(&(*ballSpace)[row][col + 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 3:
                    if ((row - 1) >= 0 && (col + 1) < ballsInARow) {
                        neighbors.push_back(&(*ballSpace)[row - 1][col + 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 4:
                    if ((row - 1) >= 0) {
                        neighbors.push_back(&(*ballSpace)[row - 1][col]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 5:
                    if ((col - 1) >= 0) {
                        neighbors.push_back(&(*ballSpace)[row][col - 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;
            }
        } else if (row % 2 == 1) {
            switch (neighbor) {
                case 0:
                    if ((row + 1) < maxRows && (col - 1) >= 0) {
                        neighbors.push_back(&(*ballSpace)[row + 1][col - 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 1:
                    if ((row + 1) < maxRows) {
                        neighbors.push_back(&(*ballSpace)[row + 1][col]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 2:
                    if ((col + 1) < ballsInARow) {
                        neighbors.push_back(&(*ballSpace)[row][col + 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 3:
                    if ((row - 1) >= 0) {
                        neighbors.push_back(&(*ballSpace)[row - 1][col]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 4:
                    if ((row - 1) >= 0 && (col - 1) >= 0) {
                        neighbors.push_back(&(*ballSpace)[row - 1][col - 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;

                case 5:
                    if ((col - 1) >= 0) {
                        neighbors.push_back(&(*ballSpace)[row][col - 1]);
                    } else {
                        neighbors.push_back(nullptr);
                    }
                    break;
            }
        }
    }
    return neighbors;
}

vector<vector<BallCell>> initializeBallSpace() {
    vector<vector<BallCell>> ballSpace = createBallSpaceRaw(4 * (ballDiameter - 9));
    extendUnderBallSpace(&ballSpace);

    return ballSpace;
}

vector<vector<BallCell>> createBallSpaceRaw(double startingY) {
    // initialize the ballSpace with empty cells
    vector<vector<BallCell>> ballSpace(ballRows, vector<BallCell>(ballsInARow, BallCell()));
    // assign topLeftX, topLeftY, status, color1, color2, locked
    for (int row = 0; row < ballRows; row++) {
        for (int col = 0; col < ballsInARow; col++) {
            // assign them coordinates and row col
            ballSpace[row][col].topLeftX = (row % 2 != 0) ? col * ballDiameter : ballDiameter / 2 +
                                                                                 col * ballDiameter;
            ballSpace[row][col].topLeftY = startingY - row * (ballDiameter - 9);
//            ballSpace[row][col].row = row;
//            ballSpace[row][col].col = col;
            // fill color1
            if (ballSpace[row][col].status == "empty" && randomSelectionBasedOnProbability(fillProbability)) {
                vector<double> colorsProbability;
                if (row == ballSpace.size() - 1) {
                    colorsProbability = {0, 13, 13, 20, 20, 20, 0};
                } else {
                    colorsProbability = {0, 13, 13, 20, 20, 20, 2};
                }
                ballSpace[row][col].color1 = randomSelectionBasedOnProbability(colorsProbability);
                ballSpace[row][col].status = "containing";
                // spread color1
//                vector<double> spreadProbability = {1, 3};
//                bool possibleToSpread = true;
                vector<double> neighborSelectionChances;
                vector<BallCell *> neighbors = returnNeighbors(&ballSpace, row, col);
                for (int neighborIndex = 0; neighborIndex < 6; neighborIndex++) {
                    if (neighbors[neighborIndex] == nullptr || neighbors[neighborIndex]->status != "empty") {
                        neighborSelectionChances.push_back(0);
                    } else {
                        neighborSelectionChances.push_back(20);
                    }
                }
                while (ballSpace[row][col].color1 != 6 &&
                       randomSelectionBasedOnProbability(spreadProbability)) {
//                    possibleToSpread = false;
                    int spreadTo = randomSelectionBasedOnProbability(neighborSelectionChances);
                    if (spreadTo == -1) break;
//                    if (neighbors[spreadTo]->color1 == 0) {
                    neighbors[spreadTo]->color1 = ballSpace[row][col].color1;
                    neighbors[spreadTo]->status = "containing";
                    neighborSelectionChances[spreadTo] = 0;
//                    } else {
//                        neighborSelectionChances[spreadTo] = 0;
//                        continue;
//                    }
                    // put the scode1 here if the lines above stopped to work suddenly
                    //check if possible to spread
//                    for (double probability: neighborSelectionChances) {
//                        if ((int) probability != 0) {
//                            possibleToSpread = true;
//                        }
//                    }
//                    spreadProbability[0]++;
                    spreadProbability[1]--;
                }
            }
            // assign locked or not
            if (ballSpace[row][col].status == "containing" && ballSpace[row][col].color1 != 6 &&
                randomSelectionBasedOnProbability(lockProbability)) {
                ballSpace[row][col].locked = true;
            }
            // set color2
            if (ballSpace[row][col].status == "containing" && ballSpace[row][col].color1 != 6 &&
                ballSpace[row][col].color2 == 0 && !ballSpace[row][col].locked &&
                randomSelectionBasedOnProbability(color2Probability)) {
                vector<double> secondColorsProbability = {0, 20, 20, 20, 20, 20, 20};
                secondColorsProbability[ballSpace[row][col].color1] = 0;
                ballSpace[row][col].color2 =
                        randomSelectionBasedOnProbability(secondColorsProbability);
            }
        }
    }
    // check if any is fallen
    updateColAndRowsOfBallSpace(&ballSpace);
    vector<vector<BallCell>> fallenDetector = fellBalls(ballSpace);
    for (int i = 0; i < ballRows; i++) {
        for (int j = 0; j < ballsInARow; j++) {
            if (fallenDetector[i][j].fallen) {
                ballSpace[i][j].status = "empty";
                ballSpace[i][j].color1 = 0;
                ballSpace[i][j].color2 = 0;
                ballSpace[i][j].locked = false;
            }
        }
    }
    return ballSpace; // ball cells in the current ballSpace lack row and col and only have the status of whether "empty" or "containing"
}

void updateColAndRowsOfBallSpace(vector<vector<BallCell>> *ballSpace) {
    for (int row = 0; row < (*ballSpace).size(); row++) {
        for (int col = 0; col < (*ballSpace)[row].size(); col++) {
            (*ballSpace)[row][col].row = row;
            (*ballSpace)[row][col].col = col;
        }
    }
}

void extendUnderBallSpace(vector<vector<BallCell>> *ballSpace) {
    cout << "extending ballSpace from below" << endl;
    vector<BallCell> extension0(ballsInARow, BallCell());
    vector<BallCell> extension1(ballsInARow, BallCell());
    for (int i = 0; i < ballsInARow; i++) {
        extension1[i].topLeftY = (*ballSpace)[0][0].topLeftY + (ballDiameter - 9);
        extension1[i].topLeftX = i * ballDiameter;
        extension0[i].topLeftY = (*ballSpace)[0][0].topLeftY + 2 * (ballDiameter - 9);
        extension0[i].topLeftX = ballDiameter / 2 + i * ballDiameter;
    }
    (*ballSpace).insert((*ballSpace).begin(), extension1);
    (*ballSpace).insert((*ballSpace).begin(), extension0);
    updateColAndRowsOfBallSpace(ballSpace);
    cout << "done extending ballSpace from below" << endl;
}

void cutUnderBallSpace(vector<vector<BallCell>> *ballSpace) {
    cout << "cutting ballSpace from below" << endl;
    (*ballSpace).erase((*ballSpace).begin(), (*ballSpace).begin() + 2);
    updateColAndRowsOfBallSpace(ballSpace);
    cout << "done cutting ballSpace from below" << endl;
}

void extendAboveBallSpace(vector<vector<BallCell>> *ballSpace) {
    cout << "extending ballSpace from above" << endl;
    vector<vector<BallCell>> extension = createBallSpaceRaw(
            (*ballSpace)[(*ballSpace).size() - 1][0].topLeftY - (ballDiameter - 9)); // changed + to -
    for (auto extensionRow: extension) { // changed &extensionRow to extensionRow
        (*ballSpace).push_back(extensionRow);
    }
    updateColAndRowsOfBallSpace(ballSpace);
    cout << "done extending ballSpace from above" << endl;
}


vector<ActionBall> initializeCannonBalls(vector<bool> presentColors) {
    vector<ActionBall> cannonBalls(2, ActionBall());
    vector<double> colorsProbability;
    for (bool presentColor: presentColors) {
        if (presentColor) {
            colorsProbability.push_back(20.0);
        } else {
            colorsProbability.push_back(0.0);
        }
    }
    colorsProbability[0] = 0;
    colorsProbability[1] = !presentColors[1] ? 0 : 12;
    colorsProbability[2] = !presentColors[2] ? 0 : 11;
    colorsProbability[6] = 0;
    colorsProbability.push_back(60); // wild ball probability
    for (ActionBall &cannonBall: cannonBalls) {
        cannonBall.color = randomSelectionBasedOnProbability(colorsProbability);
        if (cannonBall.color == 1 || cannonBall.color == 2) {
            colorsProbability[cannonBall.color] -= 6;
        } else if (cannonBall.color != 7) {
            colorsProbability[cannonBall.color] -= 12;
        }
        cannonBall.type = "cannonBall";
    }
    return cannonBalls;
}

vector<ActionBall> initializeBombs(int count) {
    vector<ActionBall> bombs(count, ActionBall());
    for (auto &bomb: bombs) {
        bomb.color = 8;
        bomb.type = "bomb";
    }
    return bombs;
}

vector<double> centerOfTexture(double topLeftX, double width, double topLeftY, double height) {
    vector<double> center(2, 0);
    center[0] = topLeftX + width / 2;
    center[1] = topLeftY + height / 2;
    return center;
}

vector<double> topLeftOfTexture(double centerX, double width, double centerY, double height) {
    vector<double> topLeft(2, 0);
    topLeft[0] = centerX - width / 2;
    topLeft[1] = centerY - height / 2;
    return topLeft;
}

double calculateAngle(double x1, double y1, double x2, double y2, bool rad) {
    double dX = x2 - x1;
    double dY = y2 - y1;
    double angle = atan2(dY, dX);
    if (rad) {
        return angle + M_PI / 2;
    }
    angle *= (180.0 / M_PI);
    angle = fmod(angle + 360, 360);
    return angle + 90;
}

string reverseStr(string input) {
    string reversed;
    for (int i = input.length() - 1; i >= 0; --i) {
        reversed.push_back(input[i]);
    }
    return reversed;
}


double angleToRad(double angle) {
    return angle * M_PI / 180.0;
}


void getMousePosition(double &mouseX, double &mouseY) {
    int x, y;
    SDL_GetMouseState(&x, &y);
    mouseX = (double) x;
    mouseY = (double) y;
}

vector<double> getLinearEq(double x1, double y1, double x2, double y2) {
    double a = (y2 - y1) / (x2 - x1);
    double b = y1 - (a * x1);
    return {a, b};
}

double solveLinearEqForY(vector<double> eq, double x) {
    return eq[0] * x + eq[1];
}

double solveLinearEqForX(vector<double> eq, double y) {
    return (y - eq[1]) / eq[0];
}

string textureCode(string preCode, int color) {
    return preCode + to_string(color);
}

bool popBallCell(vector<vector<BallCell>> *ballSpace, BallCell *ballCell,
                 int &counter) { // still not the ultimate ball popping algorithm
    vector<BallCell *> neighbors = returnNeighbors(ballSpace, ballCell->row, ballCell->col);
    vector<bool> passToNeighbor(6, false);
    for (int i = 0; i < 6; i++) {
        if (neighbors[i] != nullptr && neighbors[i]->status == "containing" && neighbors[i]->color1 != 6 &&
            haveTheSameColor(ballCell, neighbors[i])) {
            if (neighbors[i]->locked) {
                neighbors[i]->status = "justUnlocked";
                cout << ballCell->row << ":" << ballCell->col << " " << ballCell->color1 << ballCell->color2
                     << " unlocked " << neighbors[i]->row << ":"
                     << neighbors[i]->col << " " << neighbors[i]->color1 << neighbors[i]->color2 << endl;
            } else {
                neighbors[i]->status = "pop";
                counter++;
                cout << ballCell->row << ":" << ballCell->col << " " << ballCell->color1 << ballCell->color2
                     << " popped " << neighbors[i]->row << ":"
                     << neighbors[i]->col << " " << neighbors[i]->color1 << neighbors[i]->color2 << endl;
            }
            passToNeighbor[i] = true;
        }
    }
    for (int i = 0; i < 6; i++) {
        if (passToNeighbor[i]) {
            popBallCell(ballSpace, neighbors[i], counter);
        }
    }
    if (counter < 3) {
        // revert neighbors
        for (int i = 0; i < 6; i++) {
            if (passToNeighbor[i] && neighbors[i]->status == "pop") {
                neighbors[i]->status = "containing";
                cout << "pop revert for " << neighbors[i]->row << ":" << neighbors[i]->col << endl;
            }
        }
        return false;
    }
    return true;
}

void detonate(vector<vector<BallCell>> *ballSpace, BallCell *ballCell, int &counter) {
    vector<BallCell *> neighbors = returnNeighbors(ballSpace, ballCell->row, ballCell->col);
    vector<bool> passToNeighbor(6, false);
    for (int i = 0; i < 6; i++) {
        if (neighbors[i] != nullptr && neighbors[i]->status != "pop") {
            neighbors[i]->status = "pop";
            cout << ballCell->row << ":" << ballCell->col << " " << ballCell->color1 << ballCell->color2
                 << " detonated " << neighbors[i]->row << ":"
                 << neighbors[i]->col << " " << neighbors[i]->color1 << neighbors[i]->color2 << endl;
            passToNeighbor[i] = true;
        }
    }
    counter++;
    if (counter > 4) return;
    for (int i = 0; i < 6; i++) {
        if (passToNeighbor[i]) {
            detonate(ballSpace, neighbors[i], counter);
        }
    }
}


double calculateDistance(double x1, double y1, double x2, double y2) {
    return sqrt(
            pow(x2 - x1, 2) +
            pow(y2 - y1, 2));
}

BallCell *
stickActionBall(vector<vector<BallCell>> *ballSpace, vector<ActionBall> *shotBalls, BallCell *collidedBallCell,
                int shotBallIndex) {
    // check that which one could be the host
    ActionBall shotBall = (*shotBalls)[shotBallIndex];
    vector<BallCell *> probableHosts = returnNeighbors(ballSpace, collidedBallCell->row, collidedBallCell->col);
    vector<int> itemsToRemove;
    for (int i = 0; i < 6; i++) {
        if (probableHosts[i] == nullptr ||
            probableHosts[i]->status != "empty") { // this line might need a revert to == "containing"
            itemsToRemove.push_back(i);
        }
    }
    sort(itemsToRemove.begin(), itemsToRemove.end(), [](int a, int b) { return a > b; });
    for (int index: itemsToRemove) {
        probableHosts.erase(probableHosts.begin() + index);
    }
    BallCell *host = probableHosts[0];
    double hostDistance = calculateDistance(host->topLeftX + ballDiameter / 2, host->topLeftY + ballDiameter / 2,
                                            shotBall.centerX, shotBall.centerY);
    for (BallCell *probableHost: probableHosts) {
        double distance = calculateDistance(probableHost->topLeftX + ballDiameter / 2,
                                            probableHost->topLeftY + ballDiameter / 2,
                                            shotBall.centerX,
                                            shotBall.centerY);
        if (distance < hostDistance) {
            host = probableHost;
            hostDistance = distance;
        }
    }
    // changing the setting of the host
    host->color1 = shotBall.color;
    host->status = "containing";
    // removing the shotBall
    (*shotBalls).erase((*shotBalls).begin() + shotBallIndex);
    cout << "host: " << host->row << " " << host->col << endl;
    return host;
}

void saveNonFallenBalls(vector<vector<BallCell>> *ballSpaceCopy, BallCell *ballCell) {
    ballCell->fallen = false;
    vector<BallCell *> neighbors = returnNeighbors(ballSpaceCopy, ballCell->row, ballCell->col);
    for (BallCell *neighbor: neighbors) {
        if (neighbor != nullptr && neighbor->fallen) {
            saveNonFallenBalls(ballSpaceCopy, neighbor);
        }
    }
}

vector<vector<BallCell>> fellBalls(vector<vector<BallCell>> ballSpaceCopy) {
    int lastRow = ballSpaceCopy.size() - 1;
    for (int row = lastRow - 1; row >= 0; row--) {
        for (int col = 0; col < ballSpaceCopy[row].size(); col++) {
            if (ballSpaceCopy[row][col].status == "containing" || ballSpaceCopy[row][col].status == "justUnlocked") {
                ballSpaceCopy[row][col].fallen = true;
            }
        }
    }
    for (int col = 0; lastRow > 0 && col < ballSpaceCopy[lastRow].size(); col++) {
        if (ballSpaceCopy[lastRow][col].status == "containing" ||
            ballSpaceCopy[lastRow][col].status == "justUnlocked") {
            saveNonFallenBalls(&ballSpaceCopy, &ballSpaceCopy[lastRow][col]);
        }
    }
    return ballSpaceCopy;
}

void printUserVector(const std::vector<USER_STRUCT> &users) {
    for (const auto &user: users) {
        std::cout << "Username: " << user.username << std::endl;
        std::cout << "Highest Inf Score: " << user.highestInfScore << std::endl;
        std::cout << "Highest Time Score: " << user.highestTimeScore << std::endl;
        std::cout << "Highest Casual Score: " << user.highestCasualScore << std::endl;
        std::cout << "Bombs: " << user.bombs << std::endl;
        std::cout << "Lasers: " << user.lasers << std::endl;
        std::cout << "---------------------" << std::endl;
    }
}

void
updateBallVectorsData(vector<vector<BallCell>> *ballSpace, vector<ActionBall> *cannonBalls, vector<ActionBall> *bombs,
                      vector<ActionBall> *shotBalls, vector<ActionBall> *fallenBalls, vector<ActionBall> *popBalls,
                      vector<vector<double>> *laserPoints, vector<vector<double>> *laserEndPoints,
                      vector<BallCell> *laserDestroys,
                      double laserAngle,
                      vector<bool> *presentColors) {
    // process ballSpace
    if (MODE == "inf" && (*ballSpace)[(*ballSpace).size() - 2][0].topLeftY >= 0) {
        extendAboveBallSpace(ballSpace);
    }
    bool cutUnderTheBallSpace = true;
    for (int row = 0; row < 4 && (*ballSpace).size() > 4; row++) {
        for (int col = 0; col < (*ballSpace)[row].size(); col++) {
            if ((*ballSpace)[row][col].status == "containing") {
                cutUnderTheBallSpace = false;
            }
        }
    }
    if (cutUnderTheBallSpace && (*ballSpace).size() > 4) {
        cutUnderBallSpace(ballSpace);
    }
    vector<vector<BallCell>> ballSpaceCopy = fellBalls(*ballSpace);
    bool extendUnderTheBallSpace = false;
    // specify laserPoints
    (*laserEndPoints).push_back({(*laserPoints)[0][0], (*laserPoints)[0][1], 0});
    while ((*laserPoints)[(*laserPoints).size() - 1][1] > 0) {
        int currentLastIndex = (*laserPoints).size() - 1;
        double nextX = (*laserPoints)[currentLastIndex][0] + (ballDiameter * 3 / 6) * cos(angleToRad(laserAngle - 90));
        double nextY = (*laserPoints)[currentLastIndex][1] - (ballDiameter * 3 / 6) * sin(-angleToRad(laserAngle - 90));
        if (nextX > WIDTH) {
            nextX = (double) WIDTH;
            nextY = (*laserPoints)[currentLastIndex][1] - (WIDTH - (*laserPoints)[currentLastIndex][0]) * tan(
                    -angleToRad(laserAngle - 90));
            laserAngle = -1 * laserAngle;
            (*laserEndPoints).push_back({nextX, nextY, 0});
        } else if (nextX < 0) {
            nextX = 0;
            nextY = (*laserPoints)[currentLastIndex][1] - ((*laserPoints)[currentLastIndex][0]) * tan(
                    angleToRad(laserAngle - 90));
            laserAngle = -1 * laserAngle;
            (*laserEndPoints).push_back({nextX, nextY, 0});
        }
        (*laserPoints).push_back({nextX, nextY, 0});
    }
    (*laserEndPoints).push_back(
            {(*laserPoints)[(*laserPoints).size() - 1][0], (*laserPoints)[(*laserPoints).size() - 1][1], 0});
    bool laserHitTheFirstElement = false;
    vector<vector<int>> laserPointIndexByHitBalls((*ballSpace).size(), vector<int>(ballsInARow, -1));
    for (int i = 0; i < (*laserPoints).size(); i++) {
        if ((*laserPoints)[i][1] < (*ballSpace)[0][0].topLeftY + ballDiameter) {
            double deltaHeight = (*ballSpace)[0][0].topLeftY + ballDiameter - (*laserPoints)[i][1];
            int pointRow = (deltaHeight / (ballDiameter - 9));
            if (pointRow >= (*ballSpace).size()) continue;
            int pointCol;
            if (pointRow % 2 == 0) {
                double deltaWidth = (*laserPoints)[i][0] - ballDiameter / 2;
                if (deltaWidth < 0) continue;
                pointCol = (deltaWidth / ballDiameter);
            } else {
                double pointWidth = (*laserPoints)[i][0];
                pointCol = (pointWidth / ballDiameter);
                if (pointCol > 15) continue;
            }
            if (laserPointIndexByHitBalls[pointRow][pointCol] == -1) {
                laserPointIndexByHitBalls[pointRow][pointCol] = i;
            }
        }
    }
    for (int row = 0; (*ballSpace).size() > row; row++) { // change the status' in this loop
        for (int col = 0; col < (*ballSpace)[row].size(); col++) {
            BallCell currentBallCell = (*ballSpace)[row][col];
            if (currentBallCell.status == "containing" && currentBallCell.topLeftY + ballDiameter > HEIGHT - 108) {
                if (MODE == "time") {
                    CURRENT_USER->highestTimeScore = (USER_SCORE > CURRENT_USER->highestTimeScore) ? USER_SCORE
                                                                                                   : CURRENT_USER->highestTimeScore;
                    STATE = "gameOver";
                } else if (MODE == "inf") {
                    if (USER_SCORE > CURRENT_USER->highestInfScore) {
                        CURRENT_USER->highestInfScore = USER_SCORE;
                        STATE = "won";
                    } else {
                        STATE = "gameOver";
                    }
                } else if (MODE == "casual") {
                    CURRENT_USER->highestCasualScore = (USER_SCORE > CURRENT_USER->highestCasualScore) ? USER_SCORE
                                                                                                       : CURRENT_USER->highestCasualScore;
                    STATE = "gameOver";
                }
                saveDataToCSV(usersData, "usersData.csv");
            }
            // laser stuff
            if (currentBallCell.topLeftY > 0 && laserPointIndexByHitBalls[row][col] != -1) {
                if (currentBallCell.status == "containing") {
//                    cout << "laser in " << currentBallCell.row << ":" << currentBallCell.col << endl;
//                    cout << "laser in " << currentBallCell.topLeftX << ":" << currentBallCell.topLeftY << "  "
//                         << (*laserPoints)[laserPointIndexByHitBalls[row][col]][0] << ":"
//                         << (*laserPoints)[laserPointIndexByHitBalls[row][col]][1] << endl;
                    if (CANNON_LASER_SHOT) {
                        (*ballSpace)[row][col].status = "pop";
                        continue;
                    }
                    if (!laserHitTheFirstElement) {
                        (*laserEndPoints).push_back({(*laserPoints)[laserPointIndexByHitBalls[row][col]][0],
                                                     (*laserPoints)[laserPointIndexByHitBalls[row][col]][1], 1});
                        laserHitTheFirstElement = true;

                    }
                    (*laserPoints)[laserPointIndexByHitBalls[row][col]][2] = 1;
                } else {

                }
            }
            if (ballSpaceCopy[row][col].fallen) {
                (*ballSpace)[row][col].status = "fallen";
            }
            if (currentBallCell.status == "containing" && (currentBallCell.row - 2) < 0) {
                extendUnderTheBallSpace = true;
            }
            // handle collision
            for (int shotBallIndex = 0;
                 shotBallIndex < shotBalls->size() && currentBallCell.status == "containing"; shotBallIndex++) {
                ActionBall candidateStickingShotBall = (*shotBalls)[shotBallIndex];
                double centerDistance = calculateDistance(currentBallCell.topLeftX + ballDiameter / 2,
                                                          currentBallCell.topLeftY + ballDiameter / 2,
                                                          candidateStickingShotBall.centerX +
                                                          candidateStickingShotBall.speedX,
                                                          candidateStickingShotBall.centerY +
                                                          candidateStickingShotBall.speedY);
                if (centerDistance < ballDiameter * 3 / 5) {
                    // check that which ball has actually collided with
                    vector<BallCell *> currentBallCellNeighbors = returnNeighbors(ballSpace, row, col);
                    BallCell *collidedBallCell = &(*ballSpace)[row][col];
                    double leastNeighborCenterDistance = centerDistance;
                    for (int i = 0; i < 6; i++) {
                        if (currentBallCellNeighbors[i] != nullptr &&
                            currentBallCellNeighbors[i]->status == "containing") {
                            double neighborCenterDistance = calculateDistance(
                                    currentBallCellNeighbors[i]->topLeftX + ballDiameter / 2,
                                    currentBallCellNeighbors[i]->topLeftY + ballDiameter / 2,
                                    candidateStickingShotBall.centerX,
                                    candidateStickingShotBall.centerY);
                            if (neighborCenterDistance < leastNeighborCenterDistance) {
                                collidedBallCell = currentBallCellNeighbors[i];
                                leastNeighborCenterDistance = neighborCenterDistance;
                            }
                        }
                    }
                    cout << "collided: " << collidedBallCell->row << " " << collidedBallCell->col << endl;
                    // now what would happen after collision?
                    BallCell *stuckActionBall = stickActionBall(ballSpace, shotBalls, collidedBallCell, shotBallIndex);
                    int popCounter = 1;
                    stuckActionBall->status = "pop";
                    if (stuckActionBall->color1 != 8) {
                        if (!popBallCell(ballSpace, stuckActionBall, popCounter)) {
                            stuckActionBall->status = "containing";
                            if (stuckActionBall->color1 == 7) {
                                stuckActionBall->color1 = (collidedBallCell->color1 != 6) ? collidedBallCell->color1
                                                                                          : 1;
                            }
                        }
                    } else {
                        detonate(ballSpace, stuckActionBall, popCounter);
                    }
                }
            }
        }
    }
    if (extendUnderTheBallSpace) {
        extendUnderBallSpace(ballSpace);
    }
    for (int row = 0; row < (*ballSpace).size(); row++) { // apply the changes in this loop
        for (int col = 0; col < (*ballSpace)[row].size(); col++) {
            BallCell *currentBallCell = &(*ballSpace)[row][col];
            if (currentBallCell->status == "containing") {
                (*presentColors)[currentBallCell->color1] = true;
                (*presentColors)[currentBallCell->color2] = true;
//                cout << "containing " << currentBallCell->row << ":" << currentBallCell->col << " "
//                     << currentBallCell->color1 << currentBallCell->color2 << endl;
            } else if (currentBallCell->status == "pop") {
                ActionBall newPopBall = ActionBall();
                newPopBall.type = "popBall";
                newPopBall.centerX = currentBallCell->topLeftX + ballDiameter / 2;
                newPopBall.centerY = currentBallCell->topLeftY + ballDiameter / 2;
                newPopBall.speedY = currentBallCell->speedY;
                newPopBall.maxAnimationLevel = 11;
                (*popBalls).push_back(newPopBall);
                currentBallCell->status = "empty";
                currentBallCell->color1 = 0;
                currentBallCell->color2 = 0;
                currentBallCell->locked = false;
                if (currentBallCell->timeEffect) {
                    if (randomSelectionBasedOnProbability({1, 0})) {
                        stopApproach = true;
                    } else {
                        slowMotion = 1000;
                    }
                    currentBallCell->timeEffect = false;
                    TIME_EFFECT_APPLIED = false;
                    cout << "time effect applied" << endl;
                }
                USER_SCORE++;
            } else if (currentBallCell->status == "fallen") {
                cout << currentBallCell->status << " " << currentBallCell->row << " " << currentBallCell->col << " C"
                     << currentBallCell->color1 << endl;
                ActionBall newFallenBall = ActionBall();
                newFallenBall.type = "fallenBall";
                newFallenBall.centerX = currentBallCell->topLeftX + ballDiameter / 2;
                newFallenBall.centerY = currentBallCell->topLeftY + ballDiameter / 2;
                newFallenBall.color = currentBallCell->color1;
                newFallenBall.color2 = currentBallCell->color2;
                newFallenBall.speedY = FALLEN_BALL_SPEED_Y;
                (*fallenBalls).push_back(newFallenBall);
                currentBallCell->status = "empty";
                currentBallCell->color1 = 0;
                currentBallCell->color2 = 0;
                currentBallCell->locked = false;
                if (currentBallCell->timeEffect) {
                    if (randomSelectionBasedOnProbability({1, 0})) {
                        stopApproach = true;
                    } else {
                        slowMotion = 1000;
                    }
                    currentBallCell->timeEffect = false;
                    TIME_EFFECT_APPLIED = false;
                    cout << "time effect applied" << endl;
                }
                USER_SCORE++;
            } else if (currentBallCell->status == "justUnlocked") {
//                cout << "just unlocked " << currentBallCell->row << ":" << currentBallCell->col << " "
//                     << currentBallCell->color1 << currentBallCell->color2 << endl;
                currentBallCell->locked = false;
                currentBallCell->status = "containing";
                USER_SCORE++;
                (*presentColors)[currentBallCell->color1] = true;
                (*presentColors)[currentBallCell->color2] = true;
            }
        }
    }
    (*laserPoints).erase((*laserPoints).begin(), (*laserPoints).end());
    CANNON_LASER_SHOT = false;
    // low tax time effect application
    if (!TIME_EFFECT_APPLIED && randomSelectionBasedOnProbability({1, 4})) {
        int row = randomSelectionBasedOnProbability({0, 0, 1, 1});
        int col = int(randomDouble(32)) % 16;
        if ((*ballSpace)[row][col].status == "containing" && !(*ballSpace)[row][col].locked &&
            (*ballSpace)[row][col].color1 != 6) {
            (*ballSpace)[row][col].timeEffect = true;
            TIME_EFFECT_APPLIED = true;
        }
    }
    // check wining status
    bool won = true;
    for (int col = 0; col < ballsInARow; col++) {
        if ((*ballSpace)[(*ballSpace).size() - 1][col].status != "empty") {
            won = false;
        }
    }
    if (won) {
        if (MODE == "time") {
            USER_SCORE += round(REMAINING_TIME * 10);
            CURRENT_USER->highestTimeScore = (USER_SCORE > CURRENT_USER->highestTimeScore) ? USER_SCORE
                                                                                           : CURRENT_USER->highestTimeScore;
            STATE = "won";
        } else if (MODE == "casual") {
            CURRENT_USER->highestCasualScore = (USER_SCORE > CURRENT_USER->highestCasualScore) ? USER_SCORE
                                                                                               : CURRENT_USER->highestCasualScore;
            STATE = "won";

        }
        saveDataToCSV(usersData, "usersData.csv");
    }
    // process cannonBalls or bombBalls
    if (BOMB_SHOT) {
        ActionBall bomb = (*bombs)[0];
        bomb.type = "shotBall";
        (*shotBalls).push_back(bomb);
        (*bombs).erase((*bombs).begin());
        BOMB_SHOT = false;
    } else {
        for (int i = 0; i < 2 && cannonBalls->size() != 0; i++) {
            ActionBall cannonBall = (*cannonBalls)[i];
            if (cannonBall.type == "shotBall") {
                (*shotBalls).push_back(cannonBall);
                (*cannonBalls).erase((*cannonBalls).begin(), (*cannonBalls).end());
                break;
            }
        }
        if (cannonBalls->size() == 0 && shotBalls->size() == 0) {
            (*cannonBalls) = initializeCannonBalls(*presentColors);
        }
    }
    // process popBalls
    vector<int> popBallsToRemove;
    for (int i = 0; i < popBalls->size(); i++) {
        ActionBall *popBall = &(*popBalls)[i];
        popBall->animationLevel += 0.4;
        if (popBall->animationLevel > popBall->maxAnimationLevel) {
            popBallsToRemove.push_back(i);
        }
    }
    sort(popBallsToRemove.begin(), popBallsToRemove.end(), [](int a, int b) { return a > b; });
    for (int index: popBallsToRemove) {
        popBalls->erase(popBalls->begin() + index);
        cout << endl << "removed popBall: " << index;
    }
    // process shotBalls
    vector<int> shotBallsToRemove;
    for (int i = 0; i < shotBalls->size(); i++) {
        ActionBall *shotBall = &(*shotBalls)[i];
        if (shotBall->centerY + ballDiameter / 2 < 0) {
            shotBallsToRemove.push_back(i);
        }
    }
    sort(shotBallsToRemove.begin(), shotBallsToRemove.end(), [](int a, int b) { return a > b; });
    for (int index: shotBallsToRemove) {
        shotBalls->erase(shotBalls->begin() + index);
        cout << endl << "removed shotBall: " << index;
    }
    // process fallenBalls
    vector<int> fallenBallsToRemove;
    for (int i = 0; i < fallenBalls->size(); i++) {
        ActionBall *fallenBall = &(*fallenBalls)[i];
        if (fallenBall->centerY - ballDiameter / 2 > HEIGHT) {
            fallenBallsToRemove.push_back(i);
        }
    }
    sort(fallenBallsToRemove.begin(), fallenBallsToRemove.end(), [](int a, int b) { return a > b; });
    for (int index: fallenBallsToRemove) {
        fallenBalls->erase(fallenBalls->begin() + index);
        cout << endl << "removed fallenBall: " << index;
    }
}













