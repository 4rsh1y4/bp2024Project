#ifndef PROJ_65_UTILITIES_H
#define PROJ_65_UTILITIES_H

#include <vector>
#include <string>
#include <random>
#include<cstdlib>
#include<ctime>
#include <iostream>
#include<SDL2/SDL.h>
#include"./settings.h"
#include"gameObjects.h"
#include<algorithm>
#include <fstream>
#include <sstream>

using namespace std;

extern void printUserVector(const vector<USER_STRUCT> &users);

extern void saveDataToCSV(const vector<USER_STRUCT> &data, const string &filename);

extern vector<USER_STRUCT> loadDataFromCSV(const string &filename);

extern double randomDouble(double max);

extern double pseudoRandomDouble(double max);

extern int randomSelectionBasedOnProbability(vector<double> probabilities, bool inverse = false);

extern bool haveTheSameColor(BallCell *cell1, BallCell *cell2);

extern vector<BallCell *> returnNeighbors(vector<vector<BallCell>> *ballSpace, int row, int col);

extern vector<vector<BallCell>> initializeBallSpace();

extern vector<vector<BallCell>> createBallSpaceRaw(double startingY);

extern void extendUnderBallSpace(vector<vector<BallCell>> *ballSpace);

extern void cutUnderBallSpace(vector<vector<BallCell>> *ballSpace);

extern void extendAboveBallSpace(vector<vector<BallCell>> *ballSpace);

extern void updateColAndRowsOfBallSpace(vector<vector<BallCell>> *ballSpace);

extern bool popBallCell(vector<vector<BallCell>> *ballSpace, BallCell *ballCell, int &counter);

extern void detonate(vector<vector<BallCell>> *ballSpace, BallCell *ballCell, int &counter);

extern BallCell *
stickActionBall(vector<vector<BallCell>> *ballSpace, vector<ActionBall> *shotBalls, BallCell *collidedBallCell,
                int shotBallIndex);

extern vector<ActionBall> initializeCannonBalls(vector<bool> presentColors);

extern vector<ActionBall> initializeBombs(int count);

extern vector<vector<BallCell>> fellBalls(vector<vector<BallCell>> ballSpaceCopy);

extern void saveNonFallenBalls(vector<vector<BallCell>> *ballSpaceCopy, BallCell *ballCell);

extern vector<double> centerOfTexture(double topLeftX = 0, double width = 0, double topLeftY = 0, double height = 0);

extern vector<double> topLeftOfTexture(double centerX = 0, double width = 0, double centerY = 0, double height = 0);

extern double calculateAngle(double x1, double y1, double x2, double y2, bool rad = false);

extern string reverseStr(string input);

extern double angleToRad(double angle);

extern void getMousePosition(double &mouseX, double &mouseY);

extern vector<double> getLinearEq(double x1, double y1, double x2, double y2);

extern double solveLinearEqForY(vector<double> eq, double x);

extern double solveLinearEqForX(vector<double> eq, double y);

extern void
updateBallVectorsData(vector<vector<BallCell>> *ballSpace, vector<ActionBall> *cannonBalls, vector<ActionBall> *bombs,
                      vector<ActionBall> *shotBalls, vector<ActionBall> *fallenBalls,
                      vector<ActionBall> *popBalls,
                      vector<vector<double>> *laserPoints, vector<vector<double>> *laserEndPoints,
                      vector<BallCell> *laserDestroys,
                      double laserAngle,
                      vector<bool> *presentColors);

extern string textureCode(string preCode, int color = -1);

extern int colorCode(string textureCode);

#endif //PROJ_65_UTILITIES_H
