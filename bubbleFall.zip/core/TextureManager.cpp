// put scode2 here if needed
#include "TextureManager.h"

TextureManager::TextureManager(SDL_Renderer *renderer) : renderer_(renderer) {}

TextureManager::~TextureManager() {
    // Clean up textures
    for (const auto &pair: textureMap_) {
        SDL_DestroyTexture(pair.second);
    }
}

bool TextureManager::loadTexture(const std::string &filePath, const std::string &id, bool applyAntiAliasing) {
    SDL_Surface *surface = IMG_Load(filePath.c_str());
    if (!surface) {
        std::cerr << "error loading image" << std::endl;
        return false;
    }

    if (applyAntiAliasing) {
        SDL_Surface *targetSurface = SDL_CreateRGBSurface(0, surface->w * 2, surface->h * 2, 32, 0, 0, 0, 0);
        SDL_Rect destRect = {0, 0, surface->w * 2, surface->h * 2};
        SDL_BlitScaled(surface, nullptr, targetSurface, &destRect);
        SDL_FreeSurface(surface);
        surface = targetSurface;
    }

    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer_, surface);
    SDL_FreeSurface(surface);

    if (!texture) {
        std::cerr << "error creating texture" << std::endl;
        return false;
    }

    textureMap_[id] = texture;
    return true;
}

//void TextureManager::draw(const std::string &id, int x, int y, int width, int height) {
//    SDL_Rect destRect = {x, y, width, height};
//    SDL_RenderCopy(renderer_, textureMap_[id], NULL, &destRect);
//}

void TextureManager::draw(const std::string &id, int x, int y, int width, int height, double angle, double rCenterX,
                          double rCenterY) {
    SDL_Rect destRect = {x, y, width, height};
    rCenterX = (rCenterX == -1919) ? centerOfTexture(x, width)[0] - x : rCenterX - x;
    rCenterY = (rCenterY == -1919) ? centerOfTexture(0, 0, y, height)[1] - y : rCenterY - y;
    SDL_Point center = {(int) rCenterX, (int) rCenterY};
    SDL_RenderCopyEx(renderer_, textureMap_[id], nullptr, &destRect, angle, &center, SDL_FLIP_NONE);
}

void TextureManager::drawFrame(const std::string &id, int x, int y, int width, int height, int currentRow,
                               int currentFrame) {
    SDL_Rect srcRect = {width * currentFrame, height * currentRow, width, height};
    SDL_Rect destRect = {x, y, width, height};
    SDL_RenderCopy(renderer_, textureMap_[id], &srcRect, &destRect);
}


void TextureManager::animateSprite(const std::string &id, int x, int y, int width, int height, int frameCount,
                                   int animationSpeed) {
    static int currentFrame = 0;
    static int frameDelay = animationSpeed;
    SDL_RenderClear(renderer_);
    drawFrame(id, x, y, width, height, 0, currentFrame);
    SDL_RenderPresent(renderer_);
    SDL_Delay(frameDelay);
    currentFrame = (currentFrame + 1) % frameCount;
}