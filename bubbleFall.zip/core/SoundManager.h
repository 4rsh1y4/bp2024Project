#ifndef PROJ_65_SOUNDMANAGER_H
#define PROJ_65_SOUNDMANAGER_H

#include <unordered_map>
#include <string>
#include <SDL2/SDL_mixer.h>

//class SoundManager {
//public:
//    SoundManager();
//
//    ~SoundManager();
//
//    bool loadSound(const char *filePath, const std::string &soundName);
//
//    void playSound(const std::string &soundName);
//
//    void stopSound(const std::string &soundName);  // New function for stopping a sound
//    void setVolume(const std::string &soundName, int volume);
//
//private:
//    std::unordered_map<std::string, Mix_Chunk *> sounds;
//};
class SoundManager {
public:
    SoundManager();

    ~SoundManager();

    bool loadSound(const char *filePath, const std::string &soundName);

    void playSound(const std::string &soundName);

    void stopSound(const std::string &soundName);

    void setVolume(const std::string &soundName, int volume);

private:
    struct SoundInfo {
        Mix_Chunk *sound;
        int channel;
    };

    std::unordered_map<std::string, SoundInfo> sounds;
};

#endif //PROJ_65_SOUNDMANAGER_H
