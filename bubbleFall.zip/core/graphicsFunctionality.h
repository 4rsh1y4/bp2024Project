#ifndef GRAPHICS_FUNCTIONALITY
#define GRAPHICS_FUNCTIONALITY

#include <vector>
#include <iostream>
#include "textureManager.h"
#include "TextRenderer.h"
#include "SoundManager.h"
#include "TextRenderer.h"
#include "settings.h"
#include "utilities.h"
#include"gameObjects.h"
#include<SDL2/SDL.h>

extern bool loadAssets(TextureManager *textureManager, SoundManager *soundManager, TextRenderer *textRenderer);

extern void
updateBallSpace(vector<vector<BallCell>> *ballSpace, TextureManager *textureManager, SDL_Renderer *renderer,
                int circleRGBA(SDL_Renderer *renderer, Sint16 x, Sint16 y, Sint16 rad, Uint8 r, Uint8 g, Uint8 b,
                               Uint8 a), TextRenderer *textRenderer);

extern void
updateCannonBalls(vector<ActionBall> *cannonBalls, Cannon *cannon, TextureManager *textureManager);

extern void
updateShotBalls(vector<ActionBall> *shotBalls, TextureManager *textureManager);

extern void
updateFallenBalls(vector<ActionBall> *fallenBalls, TextureManager *textureManager);

extern void
updatePopBalls(vector<ActionBall> *popBalls, TextureManager *textureManager);

extern void
drawLaser(SDL_Renderer *renderer, vector<vector<double>> *laserEndPoints,
          int thickLineRGBA(SDL_Renderer *renderer, Sint16 x1, Sint16 y1, Sint16 x2, Sint16 y2, Uint8 width, Uint8 r,
                            Uint8 g, Uint8 b, Uint8 a), bool laserShot = false);

#endif

