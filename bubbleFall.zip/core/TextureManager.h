#ifndef Proj_65_TxtrMgr
#define Proj_65_TxtrMgr

#include<iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <string>
#include <map>
#include "./utilities.h"

class TextureManager {
public:
    TextureManager(SDL_Renderer *renderer);

    ~TextureManager();

    bool loadTexture(const std::string &filePath, const std::string &id, bool applyAntiAliasing = false);

//    void draw(const std::string &id, int x, int y, int width, int height);

    void draw(const std::string &id, int x, int y, int width, int height, double angle = 0, double rCenterX = -1919,
              double rCenterY = -1919);

    void drawFrame(const std::string &id, int x, int y, int width, int height, int currentRow, int currentFrame);

    void animateSprite(const std::string &id, int x, int y, int width, int height, int frameCount, int animationSpeed);


private:
    SDL_Renderer *renderer_;
    std::map<std::string, SDL_Texture *> textureMap_;
};

#endif