#include <iostream>
#include <cmath>
#include<SDL2/SDL.h>
#include<SDL2/SDL2_gfx.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include<SDL2/SDL_mixer.h>
#include<vector>
#include<algorithm>
#include <ctime>
#include"core/TextureManager.h"
#include"core/SoundManager.h"
#include"core/TextRenderer.h"
#include "core/gameObjects.h"
#include"core/utilities.h"
#include"core/settings.h"
#include"core/graphicsFunctionality.h"

using namespace std;
vector<USER_STRUCT> usersData = loadDataFromCSV("usersData.csv");

int shootType = 0;
int collectedBombs;
int collectedLasers;
//start change
int usedBombs;
int usedLasers;
int gainedBombs;
int gainedLasers;
string sgainedBombs;
string sgainedLasers;
//end change



// initialize game objects
Cannon cannon = Cannon();
UnderCannon tower = UnderCannon();
vector<bool> presentColorsForCannonBalls = {0, 1, 1, 1, 1, 1, 0};
vector<vector<BallCell>> ballSpace;
vector<ActionBall> cannonBalls;
vector<ActionBall> bombs;
vector<ActionBall> popBalls;
vector<ActionBall> shotBalls;
vector<ActionBall> fallenBalls;
vector<vector<double>> laserPoints;
vector<vector<double>> laserEndPoints;
vector<BallCell> laserDestroys;

int main(int argc, char *argv[]) {
    int cntp = 0;
    int cntm = 0;
    int cntgo = 0;
    int cntw = 0;
    bool first = false;
    printUserVector(usersData);
    // initialize sdl
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "failed to initialize sdl: " << SDL_GetError() << std::endl;
        return 1;
    }
    if (TTF_Init() != 0) {
        SDL_Log("TTF_Init Error: %s", TTF_GetError());
        SDL_Quit();
        return false;
    }
    // create window
    SDL_Window *window = SDL_CreateWindow("Proj_65", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WIDTH,
                                          HEIGHT, SDL_WINDOW_SHOWN);
    if (!window) {
        std::cerr << "failed to create window: " << SDL_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }
    // create renderer
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        std::cerr << "failed to create window: " << SDL_GetError() << std::endl;
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }
    // initialize a texture manager
    TextureManager textureManager(renderer);
    SoundManager soundManager;
    TextRenderer textRenderer;
    loadAssets(&textureManager, &soundManager, &textRenderer);
    SDL_Event event;
    bool run = true;
    // mouse and keyboard controls
    bool rightClick = false;
    bool leftClick = false;
    bool middleClick = false;
    bool showLaser = false;
    double mouseX, mouseY;
    int mouseScroll = 0;
    char inputChar;
    bool newInputChar = false;
    bool backSpace = false;
    bool escape = false;
    bool space = false;
    bool enter = false;
    bool tab = false;
    double xm, ym;
    int skip = 40;
    int xNG1 = 4 * skip;
    int xNG2 = WIDTH - 4 * skip - 24;
    int yNG1 = 3 * skip;
    int yNG2 = HEIGHT - 3 * skip;
    int fsl = (yNG2 - yNG1) / 13;
    int widthmode = (390 * 3 * fsl) / 135;

    //debug code
//    soundManager.setVolume("theme", 64);
//    soundManager.playSound("theme");
    //debug code

    while (run) {
        // polling the events
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                if (MODE == "time") {
                    CURRENT_USER->highestTimeScore = (USER_SCORE > CURRENT_USER->highestTimeScore) ? USER_SCORE
                                                                                                   : CURRENT_USER->highestTimeScore;
                } else if (MODE == "inf" && USER_SCORE > CURRENT_USER->highestInfScore) {
                    CURRENT_USER->highestInfScore = USER_SCORE;
                } else if (MODE == "casual") {
                    CURRENT_USER->highestCasualScore = (USER_SCORE > CURRENT_USER->highestCasualScore) ? USER_SCORE
                                                                                                       : CURRENT_USER->highestCasualScore;
                }
                CURRENT_USER->bombs = bombs.size();
                saveDataToCSV(usersData, "usersData.csv");
                run = false;
            } else if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_RIGHT) {
                rightClick = true;
            } else if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                leftClick = true;
            } else if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_MIDDLE) {
                middleClick = true;
            }
//            else if (event.type == SDL_MOUSEBUTTONUP && event.button.button == SDL_BUTTON_RIGHT) {
//                rightClick = false;
//            } else if (event.type == SDL_MOUSEBUTTONUP && event.button.button == SDL_BUTTON_LEFT) {
//                leftClick = false;
//            } else if (event.type == SDL_MOUSEBUTTONUP && event.button.button == SDL_BUTTON_MIDDLE) {
//                middleClick = false;
//            }
            else if (event.type == SDL_MOUSEWHEEL) {
                mouseScroll += event.wheel.y;
            } else if (event.type == SDL_KEYDOWN) {
                SDL_Keycode keyCode = event.key.keysym.sym;
                if (keyCode > SDLK_SPACE && keyCode <= SDLK_z) {
                    inputChar = (char) keyCode;
                    newInputChar = true;
                    printf("Input Char: %c\n", inputChar);
                } else if (keyCode == SDLK_BACKSPACE) {
                    backSpace = true;
                } else if (keyCode == SDLK_SPACE) {
                    space = true;
                } else if (keyCode == SDLK_ESCAPE) {
                    escape = true;
                } else if (keyCode == SDLK_RETURN || keyCode == SDLK_KP_ENTER) {
                    enter = true;
                } else if (keyCode == SDLK_TAB) {
                    tab = true;
                }
            }
        }
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderClear(renderer);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        getMousePosition(mouseX, mouseY);
        getMousePosition(xm, ym);
        cout << "(x,y):" << xm << " " << ym << "   " << endl;
//        cout << "state=" << STATE << " " << first << endl;
        if (cntm == 0) {
            if (SOUNDMODE % 3 == 1)                                         //soundmode music main
                soundManager.playSound("arcade1");
            if (SOUNDMODE % 3 == 2)
                soundManager.playSound("arcade2");
            if (SOUNDMODE % 3 == 0)
                soundManager.playSound("arcade3");
            cntm++;
        }

        if (STATE == "game") {
            if (tab) STATE = "highScores";
            if (escape) STATE = "pause";
            if (mouseScroll != 0) {
                shootType = ((mouseScroll + shootType) % 3 + 3) % 3;
                if (shootType == 1 && bombs.size() == 0) {
                    shootType = 0;
                } else if (shootType == 2 && CURRENT_USER->lasers == 0) {
                    shootType = 0;
                }
                mouseScroll = 0;
            }
            if (leftClick) {
                if (shootType == 0) {
                    cannonBalls[0].type = "shotBall";
                } else if (shootType == 1) {
                    BOMB_SHOT = true;
                    CURRENT_USER->bombs--;
                    shootType = 0;
                } else if (shootType == 2) {
                    CANNON_LASER_SHOT = true;
                    CURRENT_USER->lasers--;
                    shootType = 0;
                }
                leftClick = false;
                if (stopApproach) {
                    stopApproach = false;
                }
                // debug code
//                soundManager.playSound("collision");
//                soundManager.stopSound("theme");
                // debug code
            } else if (rightClick) {
                if (shootType == 0) {
                    swap(cannonBalls[0], cannonBalls[1]);
                    rightClick = false;
                }
                // debug code
//                soundManager.setVolume("theme", 128);
                // debug code
            } else if (middleClick) {
                showLaser = !(showLaser);
            }
            mouseY = (mouseY > HEIGHT - 108) ? HEIGHT - 108 : mouseY;
            cannon.angle = calculateAngle(cannon.centerX, cannon.centerY + 10, mouseX, mouseY);
            laserPoints.push_back({cannon.centerX, cannon.centerY, 0});
            updateBallVectorsData(&ballSpace, &cannonBalls, &bombs, &shotBalls, &fallenBalls, &popBalls, &laserPoints,
                                  &laserEndPoints, &laserDestroys,
                                  cannon.angle,
                                  &presentColorsForCannonBalls);
//            cout << "number of rows: " << ballSpace.size() << endl;
            // power bar
            boxRGBA(renderer, 0, HEIGHT - 108, WIDTH, HEIGHT, 255, 0, 255, 255);
            textureManager.draw("bomb", 0, HEIGHT - 108, 100, 100);
            textRenderer.renderText(renderer, to_string(bombs.size()) + "x", "vazir24", 100, HEIGHT - 68, 255, 255,
                                    255);
            if (shootType == 1) {
                textRenderer.renderText(renderer, "__", "vazir24", 100, HEIGHT - 68, 255, 255, 255);
            }
            textureManager.draw("lightning", 140, HEIGHT - 88, 70, 70);
            textRenderer.renderText(renderer, to_string(CURRENT_USER->lasers) + "x", "vazir24", 210, HEIGHT - 68, 255,
                                    255,
                                    255);
            if (shootType == 2) {
                textRenderer.renderText(renderer, "__", "vazir24", 210, HEIGHT - 68, 255, 255, 255);
            }

            textRenderer.renderText(renderer, "score: " + to_string(USER_SCORE), "vazir24", WIDTH - 250, HEIGHT - 100,
                                    255, 255, 255);
            if (MODE == "time") {
                textRenderer.renderText(renderer, "remaining time: " + to_string(int(REMAINING_TIME)) + "s", "vazir24",
                                        WIDTH - 250, HEIGHT - 70, 255, 255,
                                        255);
            }
            textRenderer.renderText(renderer, "playing as: " + CURRENT_USER->username, "vazir24", WIDTH - 250,
                                    HEIGHT - 45,
                                    255, 255, 255);
            // deadline
            thickLineRGBA(renderer, 0, HEIGHT - 108, WIDTH, HEIGHT - 108, 3, 255, 0, 0, 255);
            // draw laser
            if (showLaser && shootType != 2) {
                drawLaser(renderer, &laserEndPoints, thickLineRGBA);
            }
            // ball space
            updateBallSpace(&ballSpace, &textureManager, renderer, circleRGBA, &textRenderer);
            // draw laser shot
            if (shootType == 2) {
                drawLaser(renderer, &laserEndPoints, thickLineRGBA, true);
            }
            // shot balls
            updateShotBalls(&shotBalls, &textureManager);
            // fallen balls
            updateFallenBalls(&fallenBalls, &textureManager);
            // pop balls
            updatePopBalls(&popBalls, &textureManager);
            //cannonBalls
            if (shootType == 0) {
                updateCannonBalls(&cannonBalls, &cannon, &textureManager);
            } else if (shootType == 1) {
                updateCannonBalls(&bombs, &cannon, &textureManager);
            }
            // tower
            textureManager.draw("tower", topLeftOfTexture(tower.centerX, tower.width)[0],
                                topLeftOfTexture(0, 0, tower.centerY, tower.height)[1], tower.width,
                                tower.height);
            // cannon
            textureManager.draw("cannon", topLeftOfTexture(cannon.centerX, cannon.width)[0],
                                topLeftOfTexture(0, 0, cannon.centerY, cannon.height)[1], cannon.width,
                                cannon.height, cannon.angle,
                                cannon.centerX, cannon.centerY);
            presentColorsForCannonBalls = vector<bool>(7, false);
            int addedLasers = USER_SCORE / 220 - collectedLasers;
            int addedBombs = USER_SCORE / 180 - collectedBombs;;
            if (addedLasers > 0) {
                collectedLasers += addedLasers;
                CURRENT_USER->lasers += addedLasers;
            }
            if (addedBombs > 0) {
                collectedBombs += addedBombs;
                bombs = initializeBombs(bombs.size() + addedBombs);
                CURRENT_USER->bombs += addedBombs;
            }
            if (MODE == "time") {
                REMAINING_TIME -= (DELAY + 1) / 1000;
            }
            if (MODE == "time" && REMAINING_TIME < 0) {
                CURRENT_USER->highestTimeScore = (USER_SCORE > CURRENT_USER->highestTimeScore) ? USER_SCORE
                                                                                               : CURRENT_USER->highestTimeScore;
                saveDataToCSV(usersData, "usersData.csv");
                STATE = "gameOver";
            }

        } else if (STATE == "preGame") {
            //start change
            soundManager.stopSound("arcade1");
            soundManager.stopSound("arcade2");
            soundManager.stopSound("arcade3");
            soundManager.stopSound("yip");
            soundManager.stopSound("Lsound");
            if (cntm == 0) {
                if (SOUNDMODE % 3 == 1)                                         //soundmode music main
                    soundManager.playSound("arcade1");
                if (SOUNDMODE % 3 == 2)
                    soundManager.playSound("arcade2");
                if (SOUNDMODE % 3 == 0)
                    soundManager.playSound("arcade3");
                cntm++;
            }
            cntw = 0;
            cntgo = 0;
            cntm = 0;
            //end change
            ballSpace = initializeBallSpace();
            bombs = initializeBombs(CURRENT_USER->bombs);
            cannonBalls = initializeCannonBalls(presentColorsForCannonBalls);
            popBalls.erase(popBalls.begin(), popBalls.end());
            shotBalls.erase(shotBalls.begin(), shotBalls.end());
            fallenBalls.erase(fallenBalls.begin(), fallenBalls.end());
            laserPoints.erase(laserPoints.begin(), laserPoints.end());
            laserEndPoints.erase(laserEndPoints.begin(), laserEndPoints.end());
            collectedBombs = 0;
            collectedLasers = 0;
            USER_SCORE = 0;
            STATE = "game";
        } else if (STATE == "gameOver") {
            //start change
            if (cntgo == 0) {
                soundManager.stopSound("arcade1");
                soundManager.stopSound("arcade2");
                soundManager.stopSound("arcade3");
                soundManager.playSound("Lsound");
                cntgo++;
            }
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 2) {
                R = 6, G = 1, B = 41;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
            }
            skip = 60;
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }
            textRenderer.renderText(renderer, "<<GAME OVER>>", "bahnschrift32", 346, 200, 250, 20, 20);
            boxRGBA(renderer, 600, 243, 320, 237, 250, 20, 20, 255);
            if (!entered[0]) {
                textRenderer.renderText(renderer, "--RESTART--", "bahnschrift20", 402, 260, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--RESTART--", "bahnschrift24", 392, 258, 250, 250, 250);
            }
            if (xm > 392 && xm < 523 && ym > 258 && ym < 282) {
                entered[0] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[0] = false;
                    STATE = "preGame";
                    first = true;
                }
            } else {
                entered[0] = false;
            }
            if (!entered[1]) {
                textRenderer.renderText(renderer, "--SELECT MODE--", "bahnschrift20", 380, 300, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--SELECT MODE--", "bahnschrift24", 366, 298, 250, 250, 250);
            }
            if (xm > 366 && xm < 541 && ym > 298 && ym < 322) {
                entered[1] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[1] = false;
                    STATE = "modeSelection";
                    first = true;
                }
            } else { entered[1] = false; }


            if (entered[2]) {
                textRenderer.renderText(renderer, "--MAIN MENU--", "bahnschrift20", 393, 340, 250, 250, 250);
            } else { textRenderer.renderText(renderer, "--MAIN MENU--", "bahnschrift24", 381, 338, 250, 250, 250); }
            if (xm > 381 && xm < 534 && ym > 338 && ym < 362) {
                entered[2] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[2] = false;
                    STATE = "mainMenu";
                    first = true;
                }
            } else { entered[2] = false; }
            boxRGBA(renderer, 670, 371, 270, 369, 250, 100, 100, 105);
            textRenderer.renderText(renderer, "YOU GOT  :  ", "bahnschrift20", 290, 400, 250, 250, 250);
            if (first) {
                soundManager.stopSound("Lsound");
                BACKSTATE = "game";
                first = false;
            }
            textureManager.draw("bomb", 325, 420, 100, 100);
            textureManager.draw("lightning", 350, 520, 60, 65);
            gainedBombs = collectedBombs - usedBombs;
            gainedLasers = collectedLasers - usedLasers;


            if (gainedBombs >= 0) {
                sgainedBombs = to_string(gainedBombs);
                stoi(sgainedBombs, *gainedBombs, 10); // start change   // end change
                textRenderer.renderText(renderer, sgainedBombs, "bahnschrift20", 430, 465, 255, 255, 255);
            } else {
                textRenderer.renderText(renderer, "0", "bahnschrift20", 430, 465, 255, 255, 255);
            }


            if (gainedLasers > 0) {
                sgainedLasers = to_string(gainedLasers);
                stoi(sgainedBombs, *gainedBombs, 10); // start change   // end change
                textRenderer.renderText(renderer, sgainedLasers, "bahnschrift20", 430, 540, 255, 255, 255);
            } else {
                textRenderer.renderText(renderer, "0", "bahnschrift20", 430, 540, 255, 255, 255);
            }

//end change
//start change
        } else if (STATE == "won") {
            if (cntw == 0) {
                soundManager.stopSound("arcade1");
                soundManager.stopSound("arcade2");
                soundManager.stopSound("arcade3");
                soundManager.playSound("yip");
                cntw++;
            }
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 2) {
                R = 6, G = 1, B = 41;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
            }
            skip = 60;
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }
            textRenderer.renderText(renderer, "<<YOU WON>>", "bahnschrift32", 371, 200, 250, 20, 20);
            boxRGBA(renderer, 600, 243, 320, 237, 250, 20, 20, 255);
            if (!entered[0]) {
                textRenderer.renderText(renderer, "--RESTART--", "bahnschrift20", 402, 260, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--RESTART--", "bahnschrift24", 392, 258, 250, 250, 250);
            }
            if (xm > 392 && xm < 523 && ym > 258 && ym < 282) {
                entered[0] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[0] = false;
                    STATE = "preGame";
                    first = true;
                }
            } else {
                entered[0] = false;
            }
            if (!entered[1]) {
                textRenderer.renderText(renderer, "--SELECT MODE--", "bahnschrift20", 380, 300, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--SELECT MODE--", "bahnschrift24", 366, 298, 250, 250, 250);
            }
            if (xm > 366 && xm < 541 && ym > 298 && ym < 322) {
                entered[1] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[1] = false;
                    STATE = "modeSelection";
                    first = true;
                }
            } else { entered[1] = false; }


            if (!entered[2]) {
                textRenderer.renderText(renderer, "--MAIN MENU--", "bahnschrift20", 393, 340, 250, 250, 250);
            } else { textRenderer.renderText(renderer, "--MAIN MENU--", "bahnschrift24", 381, 338, 250, 250, 250); }
            if (xm > 381 && xm < 534 && ym > 338 && ym < 362) {
                entered[2] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[2] = false;
                    STATE = "mainMenu";
                    first = true;
                }
            } else { entered[2] = false; }
            boxRGBA(renderer, 670, 371, 270, 369, 250, 100, 100, 105);
            textRenderer.renderText(renderer, "YOU GOT  :  ", "bahnschrift20", 290, 400, 250, 250, 250);
            //what we got
            //what we got
            if (first) {
                soundManager.stopSound("Lsound");
                BACKSTATE = "game";
                first = false;
            }
            textureManager.draw("bomb", 325, 420, 100, 100);
            textureManager.draw("lightning", 350, 520, 60, 65);
            gainedBombs = collectedBombs - usedBombs;
            gainedLasers = collectedLasers - usedLasers;


            if (gainedBombs >= 0) {
                sgainedBombs = to_string(gainedBombs);
                stoi(sgainedBombs, *gainedBombs, 10); // start change   // end change
                textRenderer.renderText(renderer, sgainedBombs, "bahnschrift20", 430, 465, 255, 255, 255);
            } else {
                textRenderer.renderText(renderer, "0", "bahnschrift20", 430, 465, 255, 255, 255);
            }


            if (gainedLasers > 0) {
                sgainedLasers = to_string(gainedLasers);
                stoi(sgainedBombs, *gainedBombs, 10); // start change   // end change
                textRenderer.renderText(renderer, sgainedLasers, "bahnschrift20", 430, 540, 255, 255, 255);
            } else {
                textRenderer.renderText(renderer, "0", "bahnschrift20", 430, 540, 255, 255, 255);
            }
            //end change
        } else if (STATE == "mainMenu") {
            if (CURRENT_USER == nullptr) {
                STATE = "getUsername";
            }
            if (BACKSTATE == "game") {
                if (SOUNDMODE % 3 == 1)                                         //soundmode music main
                    soundManager.playSound("arcade1");
                if (SOUNDMODE % 3 == 2)
                    soundManager.playSound("arcade2");
                if (SOUNDMODE % 3 == 0)
                    soundManager.playSound("arcade3");
                BACKSTATE = "mainMenu";
            }
            int Xbbmm = WIDTH / 8;
            int Ybbmm = HEIGHT / 4 + 5;
            //theme background;
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
                textureManager.draw("bouncingBalls", 50, 50, 200, 200);

            }
            if (THEME % 3 == 2) {
                R = 6, G = 1, B = 41;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
                textureManager.draw("bouncingBalls", 50, 50, 200, 200);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
                textureManager.draw("bouncingBalls", Xbbmm, Ybbmm, 350, 350);
            }
            boxRGBA(renderer, 870, 230, 550, 490, R, G, B, 155);
            boxRGBA(renderer, 865, 235, 555, 485, R, G, B, 205);
            boxRGBA(renderer, 860, 240, 560, 480, R, G, B, 255);
            if (!entered[0]) { textureManager.draw("newGame", 570, 250, 280, 80); }
            else { textureManager.draw("newGamed", 570, 250, 280, 80); }
            if (!entered[1]) { textureManager.draw("menuSettings", 710, 340, 140, 140); }
            else { textureManager.draw("menuSettingsd", 710, 340, 140, 140); }
            if (!entered[2]) { textureManager.draw("highScore", 570, 340, 130, 62); }
            else { textureManager.draw("highScored", 570, 340, 130, 62); }
            if (!entered[3]) { textureManager.draw("menuQuit", 570, 412, 130, 68); }
            else { textureManager.draw("menuQuitd", 570, 412, 130, 68); }

            if (xm > 569 && xm < 849 && ym > 249 && ym < 331) {       //modeSelection
                entered[0] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[0] = false;
                    leftClick = false;
                    STATE = "modeSelection";
                }
            } else { entered[0] = false; }

            if (xm > 709 && xm < 851 && ym > 339 && ym < 481) {       //settings
                entered[1] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[1] = false;
                    leftClick = false;
                    STATE = "settings";
                }
            } else { entered[1] = false; }

            if (xm > 569 && xm < 701 && ym > 339 && ym < 403) {      //highScores
                entered[2] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[2] = false;
                    leftClick = false;
                    STATE = "highScores";
                }
            } else { entered[2] = false; }

            if (xm > 569 && xm < 701 && ym > 411 && ym < 481) {        //quit
                entered[3] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    STATE = "quit";
                    run = false;
                }
            } else { entered[3] = false; }

            if (THEME % 3 == 0) {                                     //credits
                if ((xm > Xbbmm) && (xm < Xbbmm + 350) && (ym > Ybbmm) && (ym < Ybbmm + 350)) {
                    if (leftClick) {
                        soundManager.playSound("click2");
                        leftClick = false;
                        STATE = "CR";

                    }

                }
            } else {
                if ((xm > 50) && (xm < 250) && (ym > 50) && (ym < 250)) {
                    if (leftClick) {
                        soundManager.playSound("click2");
                        leftClick = false;
                        STATE = "CR";
                    }
                }
            }
        } //start change
         else if (STATE == "pause") {
            if (cntp == 0) {
                soundManager.stopSound("arcade1");
                soundManager.stopSound("arcade2");
                soundManager.stopSound("arcade3");
                soundManager.playSound("byebye");
                cntp++;

            }
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 2) {
                R = 6, G = 1, B = 41;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
            }
            skip = 60;
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }
            textRenderer.renderText(renderer, "<<PAUSE>>", "bahnschrift32", 380, 220, 250, 250, 250);
            boxRGBA(renderer, 600, 258, 320, 262, 250, 250, 250, 255);
            if (!entered[0]) {
                textRenderer.renderText(renderer, "--RESUME--", "bahnschrift20", 400, 280, 250, 250, 250);
            } else { textRenderer.renderText(renderer, "--RESUME--", "bahnschrift24", 390, 275, 250, 250, 250); }
            if (xm > 396 && xm < 512 && ym > 276 && ym < 304) {
                entered[0] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[0] = false;
                    STATE = "unpause";
                    first = true;
                }
            } else { entered[0] = false; }


            if (!entered[1]) {
                textRenderer.renderText(renderer, "--RESTART--", "bahnschrift20", 399, 320, 250, 250, 250);
            } else { textRenderer.renderText(renderer, "--RESTART--", "bahnschrift24", 389, 315, 250, 250, 250); }
            if (xm > 397 && xm < 511 && ym > 316 && ym < 344) {
                entered[1] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[1] = false;
                    STATE = "preGame";
                    first = true;
                }
            } else { entered[1] = false; }


            if (!entered[2]) {
                textRenderer.renderText(renderer, "--SELECT MODE--", "bahnschrift20", 378, 360, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--SELECT MODE--", "bahnschrift24", 368, 355, 250, 250, 250);
            }
            if (xm > 376 && xm < 545 && ym > 356 && ym < 384) {
                entered[2] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    STATE = "modeSelection";
                    leftClick = false;
                    entered[2] = false;
                    first = true;
                }
            } else { entered[2] = false; }


            if (!entered[3]) {
                textRenderer.renderText(renderer, "--settings--", "bahnschrift20", 406, 400, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--settings--", "bahnschrift24", 396, 395, 250, 250, 250);
            }
            if (xm > 404 && xm < 538 && ym > 396 && ym < 424) {
                entered[3] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[3] = false;
                    STATE = "pauseSettings";
                }
            } else { entered[3] = false; }


            if (!entered[4]) {
                textRenderer.renderText(renderer, "--MAIN MENU--", "bahnschrift20", 389, 440, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--MAIN MENU--", "bahnschrift24", 379, 435, 250, 250, 250);
            }
            if (xm > 389 && xm < 534 && ym > 436 && ym < 464) {
                entered[4] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[4] = false;
                    STATE = "mainMenu";
                    first = true;
                }
            } else { entered[4] = false; }

            if (!entered[5]) {
                textRenderer.renderText(renderer, "--QUIT--", "bahnschrift20", 417, 480, 250, 250, 250);
            } else {
                textRenderer.renderText(renderer, "--QUIT--", "bahnschrift24", 407, 475, 250, 250, 250);
            }
            if (xm > 417 && xm < 485 && ym > 476 && ym < 504) {
                entered[5] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[5] = false;
                    STATE = "quit";
                    run = false;
                    first = true;
                }
            } else { entered[5] = false; }
            if (first) {
                soundManager.stopSound("byebye");
                cntm = 0;
                first = false;
            }
//end change
        } else if (STATE == "settings") {
             //start change
            skip = 20;
            if (SOUNDMODE == 1)
                soundManager.setVolume("arcade1", soundmusic);
            if (SOUNDMODE == 2)
                soundManager.setVolume("arcade2", soundmusic);
            if (SOUNDMODE == 0)
                soundManager.setVolume("arcade3", soundmusic);
            soundManager.setVolume("click", soundsfx);
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 2) {
                R = 64, G = 32, B = 175;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
            }
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }

            if (!entered[0]) {
                textureManager.draw("menuBack", xNG1, yNG2 - 110, 100, 100);
            } else { textureManager.draw("menuBackd", xNG1, yNG2 - 110, 100, 100); }
            boxRGBA(renderer, 150, 140, 135, 475, R + 20, G + 20, B + 20, 255);
            boxRGBA(renderer, 365, 100, 360, 230, R + 20, G + 20, B + 20, 255);
            textureManager.draw("theme", 190, 145, 150, 60);

            if (!entered[1]) { textureManager.draw("background3", 425, 95, 104, 78); }
            else {
                textureManager.draw("background3", 425, 95, 114, 88);
                filledCircleRGBA(renderer, 482, 215, 20, R + 40, G, B, 255);
                boxRGBA(renderer, 736, 195, 579, 235, R, G, B, 185);
            }

            if (!entered[2]) { textureManager.draw("background1", 547, 100, 104, 78); }
            else {
                textureManager.draw("background1", 542, 95, 114, 88);
                filledCircleRGBA(renderer, 599, 215, 20, R + 40, G, B, 255);
                boxRGBA(renderer, 502, 195, 462, 235, R, G, B, 255);
                boxRGBA(renderer, 736, 195, 696, 235, R, G, B, 185);
            }

            if (!entered[3]) { textureManager.draw("background2", 664, 100, 104, 78); }
            else {
                textureManager.draw("background2", 659, 95, 114, 88);
                filledCircleRGBA(renderer, 716, 215, 20, R + 40, G, B, 255);
                boxRGBA(renderer, 619, 195, 462, 235, R, G, B, 185);
            }
            if (THEME % 3 != 0)
                circleRGBA(renderer, 482, 215, 15, R + 40, G, B, 255);
            else {
                if (!entered[2] && !entered[3]) {
                    filledCircleRGBA(renderer, 482, 215, 20, R + 40, G, B, 200);
                } else {
                    filledCircleRGBA(renderer, 482, 215, 20, R, G, B, 200);
                    circleRGBA(renderer, 482, 215, 15, R + 40, G, B, 255);
                }
            }
            if (THEME % 3 != 1) {
                circleRGBA(renderer, 599, 215, 15, R + 40, G, B, 255);
            } else if (!entered[1] && !entered[3]) {
                filledCircleRGBA(renderer, 599, 215, 20, R + 40, G, B, 200);
            } else {
                filledCircleRGBA(renderer, 599, 215, 20, R, G, B, 200);
                circleRGBA(renderer, 599, 215, 15, R + 40, G, B, 255);
            }
            if (THEME % 3 != 2) {
                circleRGBA(renderer, 716, 215, 15, R + 40, G, B, 255);
            } else if (!entered[1] && !entered[2]) {
                filledCircleRGBA(renderer, 716, 215, 20, R + 40, G, B, 200);
            } else {
                filledCircleRGBA(renderer, 716, 215, 20, R, G, B, 200);
                circleRGBA(renderer, 716, 215, 15, R + 40, G, B, 255);
            }
            boxRGBA(renderer, 365, 265, 360, 335, R + 20, G + 20, B + 20,
                    255);                                                                                  //soundsfx muteunmute button
            if (soundsfx > 0) {
                textureManager.draw("unmute", 380, 275, 60, 49);
            } else { textureManager.draw("mute", 380, 275, 60, 49); }
            boxRGBA(renderer, 770, 297, 470, 303, 0, 0, 0, 255);
            boxRGBA(renderer, 621, 300, 622, 304, 0, 0, 0, 255);
            boxRGBA(renderer, 770, 300, 768, 304, 0, 0, 0, 255);
            boxRGBA(renderer, 471, 300, 470, 304, 0, 0, 0, 255);
            if (!entered[4]) {
                filledCircleRGBA(renderer, 470 + soundsfx * 3, 300, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundsfx * 3, 296, 469, 304, 10, 20, 10, 255);
            } else {
                filledCircleRGBA(renderer, 470 + soundsfx * 3, 300, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundsfx * 3, 296, 469, 304, 10, 20, 10, 255);
            }


            boxRGBA(renderer, 365, 350, 360, 420, R + 20, G + 20, B + 20, 255);    //sound music mute unbutton
            if (soundmusic > 0) {
                textureManager.draw("unmute", 380, 365, 60, 49);
            } else {
                textureManager.draw("mute", 380, 365, 60, 49);
            }
            boxRGBA(renderer, 770, 387, 470, 393, 0, 0, 0, 255);
            boxRGBA(renderer, 621, 390, 622, 394, 0, 0, 0, 255);
            boxRGBA(renderer, 770, 390, 768, 394, 0, 0, 0, 255);
            boxRGBA(renderer, 471, 390, 470, 394, 0, 0, 0, 255);
            if (!entered[5]) {
                filledCircleRGBA(renderer, 470 + soundmusic * 3, 390, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundmusic * 3, 386, 469, 394, 10, 20, 10, 255);
            } else {
                filledCircleRGBA(renderer, 470 + soundmusic * 3, 390, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundmusic * 3, 386, 469, 394, 10, 20, 10, 255);
            }
            textRenderer.renderText(renderer, "Select music   :", "bahnschrift24", 200, 520, 0, 0, 0);

            if (!entered[6]) {
                textRenderer.renderText(renderer, "ELECTRODYNAMICS", "bahnschrift20", 390, 522, 0, 0, 0);
            } else {
                textRenderer.renderText(renderer, "ELECTRODYNAMICS", "bahnschrift24", 388, 520, 0, 0, 0);

            }

            if (!entered[7]) {
                textRenderer.renderText(renderer, "ChipMode", "bahnschrift20", 390, 552, 0, 0, 0);
            } else {
                textRenderer.renderText(renderer, "ChipMode", "bahnschrift24", 388, 550, 0, 0, 0);

            }

            if (!entered[8]) {
                textRenderer.renderText(renderer, "IttyBitty", "bahnschrift20", 390, 582, 0, 0, 0);
            } else {
                textRenderer.renderText(renderer, "IttyBitty", "bahnschrift24", 388, 580, 0, 0, 0);

            }
            textRenderer.renderText(renderer, "SFX   :", "bahnschrift28", 235, 300, 0, 0, 0);

            textRenderer.renderText(renderer, "MUSIC   :", "bahnschrift28", 230, 375, 0, 0, 0);
            boxRGBA(renderer, 375, 510, 373, 610, 0, 0, 0, 255);

            if ((xm > 85) && (xm < 170) && (ym > 635) && (ym < 720)) {     //the back button
                entered[0] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[0] = false;
                    leftClick = false;
                    STATE = "mainMenu";
                }
            } else { entered[0] = false; }

            if ((xm > 430 && xm < 534 && ym > 100 && ym < 178) ||
                (sqrt((xm - 482) * (xm - 482) + (ym - 215) * (ym - 215)) < 20)) {  // menubackground1
                entered[1] = true;
                if (leftClick) {
                    THEME = 0;
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[1] = false;
                }
            } else { entered[1] = false; }


            if ((xm > 547 && xm < 651 && ym > 100 && ym < 178) ||
                (sqrt((xm - 599) * (xm - 599) + (ym - 215) * (ym - 215)) < 20)) {  //menubackground2
                entered[2] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[2] = false;
                    THEME = 1;
                }
            } else { entered[2] = false; }
            if ((xm > 664 && xm < 768 && ym > 100 && ym < 178) ||
                (sqrt((xm - 716) * (xm - 716) + (ym - 215) * (ym - 215)) < 20)) {
                entered[3] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    THEME = 2;
                    entered[3] = false;
                }
            } else { entered[3] = false; }


            if (xm > 380 && xm < 440 && ym > 270 && ym < 319) {
                if (leftClick) {
                    soundManager.playSound("click");
                    if (soundsfx != 0) {
                        backsoundsfx = soundsfx;
                        soundsfx = 0;
                    } else {
                        soundsfx = backsoundsfx;
                    }
                    leftClick = false;
                }
            }
            if (xm > 470 && xm < 773 && ym > 290 && ym < 310) {
                entered[4] = true;
                if (adjustings) {
                    filledCircleRGBA(renderer, xm, 300, 9, 10, 20, 10, 255);
                    boxRGBA(renderer, xm, 296, 469, 304, 10, 20, 10, 255);
                    if (leftClick) {
                        soundManager.playSound("click");
                        leftClick = false;
                        adjustings = false;
                    }
                }
                if (leftClick) {
                    adjustings = true;
                    backsoundsfx = soundsfx;
                    soundsfx = (xm - 470) / 3;
                    soundManager.playSound("click");
                    leftClick = false;
                }
            } else {
                entered[4] = false;
                adjustings = false;
            }


            if (xm > 380 && xm < 440 && ym > 365 && ym < 414) {
                if (leftClick) {
                    soundManager.playSound("click");
                    if (soundmusic != 0) {
                        backsoundmusic = soundmusic;
                        soundmusic = 0;
                    } else
                        soundmusic = backsoundmusic;
                    leftClick = false;
                }
            }
            if (xm > 470 && xm < 773 && ym > 380 && ym < 400) {
                entered[5] = true;
                if (adjustingm) {
                    filledCircleRGBA(renderer, xm, 390, 9, 10, 20, 10, 255);
                    boxRGBA(renderer, xm, 386, 469, 394, 10, 20, 10, 255);
                    if (leftClick) {
                        soundManager.playSound("click");
                        leftClick = false;
                        adjustingm = false;
                    }
                }
                if (leftClick) {
                    soundManager.playSound("click");
                    adjustingm = true;
                    backsoundmusic = soundmusic;
                    soundmusic = (xm - 470) / 3;
                    leftClick = false;
                }
            } else {
                entered[5] = false;
                adjustingm = false;
            }
            if (xm > 390 && xm < 565 && ym > 520 && ym < 540) {
                entered[6] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[6] = false;

                    soundManager.stopSound("arcade3");
                    soundManager.stopSound("arcade2");
                    soundManager.stopSound("arcade1");
                    soundManager.playSound("arcade3");
                    SOUNDMODE = 3;
                }
            } else { entered[6] = false; }

            if (xm > 390 && xm < 475 && ym > 550 && ym < 570) {
                entered[7] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[7] = false;

                    soundManager.stopSound("arcade3");
                    soundManager.stopSound("arcade2");
                    soundManager.stopSound("arcade1");
                    soundManager.playSound("arcade2");
                    SOUNDMODE = 2;
                }
            } else { entered[7] = false; }

            if (xm > 390 && xm < 600 && ym > 580 && ym < 600) {
                entered[8] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[8] = false;
                    soundManager.stopSound("arcade3");
                    soundManager.stopSound("arcade2");
                    soundManager.stopSound("arcade1");
                    soundManager.playSound("arcade1");
                    SOUNDMODE = 1;
                }
            } else { entered[8] = false; }

        }//end change
        //start change
         else if (STATE == "pauseSettings") {
            skip = 20;
            if (SOUNDMODE == 1)
                soundManager.setVolume("arcade1", soundmusic);
            if (SOUNDMODE == 2)
                soundManager.setVolume("arcade2", soundmusic);
            if (SOUNDMODE == 0)
                soundManager.setVolume("arcade3", soundmusic);
            soundManager.setVolume("byebye", soundmusic);
            soundManager.setVolume("click", soundsfx);
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 2) {
                R = 64, G = 32, B = 175;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
            }
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }


            if (!entered[0]) {
                textureManager.draw("menuBack", xNG1, yNG2 - 110, 100, 100);
            } else { textureManager.draw("menuBackd", xNG1, yNG2 - 110, 100, 100); }
            if ((xm > 85) && (xm < 170) && (ym > 635) && (ym < 720)) {     //the back button
                entered[0] = true;
                if (leftClick) {
                    entered[0] = false;
                    soundManager.playSound("click");
                    leftClick = false;
                    STATE = "pause";
                }
            } else { entered[0] = false; }


            boxRGBA(renderer, 365, 265, 360, 335, R + 20, G + 20, B + 20,
                    255);                                                                                  //soundsfx muteunmute button
            if (soundsfx > 0) {
                textureManager.draw("unmute", 380, 275, 60, 49);
            } else { textureManager.draw("mute", 380, 275, 60, 49); }
            boxRGBA(renderer, 770, 297, 470, 303, 0, 0, 0, 255);
            boxRGBA(renderer, 621, 300, 622, 304, 0, 0, 0, 255);
            boxRGBA(renderer, 770, 300, 768, 304, 0, 0, 0, 255);
            boxRGBA(renderer, 471, 300, 470, 304, 0, 0, 0, 255);
            if (!entered[4]) {
                filledCircleRGBA(renderer, 470 + soundsfx * 3, 300, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundsfx * 3, 296, 469, 304, 10, 20, 10, 255);
            } else {
                filledCircleRGBA(renderer, 470 + soundsfx * 3, 300, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundsfx * 3, 296, 469, 304, 10, 20, 10, 255);
            }


            boxRGBA(renderer, 365, 350, 360, 420, R + 20, G + 20, B + 20, 255);    //sound music mute unbutton
            if (soundmusic > 0) {
                textureManager.draw("unmute", 380, 365, 60, 49);
            } else {
                textureManager.draw("mute", 380, 365, 60, 49);
            }
            boxRGBA(renderer, 770, 387, 470, 393, 0, 0, 0, 255);
            boxRGBA(renderer, 621, 390, 622, 394, 0, 0, 0, 255);
            boxRGBA(renderer, 770, 390, 768, 394, 0, 0, 0, 255);
            boxRGBA(renderer, 471, 390, 470, 394, 0, 0, 0, 255);
            if (!entered[5]) {
                filledCircleRGBA(renderer, 470 + soundmusic * 3, 390, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundmusic * 3, 386, 469, 394, 10, 20, 10, 255);
            } else {
                filledCircleRGBA(renderer, 470 + soundmusic * 3, 390, 9, 10, 20, 10, 255);
                boxRGBA(renderer, 470 + soundmusic * 3, 386, 469, 394, 10, 20, 10, 255);
            }
            textRenderer.renderText(renderer, "Select music   :", "bahnschrift24", 200, 520, 0, 0, 0);

            if (!entered[6]) {
                textRenderer.renderText(renderer, "ELECTRODYNAMICS", "bahnschrift20", 390, 522, 0, 0, 0);
            } else {
                textRenderer.renderText(renderer, "ELECTRODYNAMICS", "bahnschrift24", 388, 520, 0, 0, 0);

            }

            if (!entered[7]) {
                textRenderer.renderText(renderer, "ChipMode", "bahnschrift20", 390, 552, 0, 0, 0);
            } else {
                textRenderer.renderText(renderer, "ChipMode", "bahnschrift24", 388, 550, 0, 0, 0);

            }

            if (!entered[8]) {
                textRenderer.renderText(renderer, "IttyBitty", "bahnschrift20", 390, 582, 0, 0, 0);
            } else {
                textRenderer.renderText(renderer, "IttyBitty", "bahnschrift24", 388, 580, 0, 0, 0);

            }
            textRenderer.renderText(renderer, "SFX   :", "bahnschrift28", 235, 300, 0, 0, 0);

            textRenderer.renderText(renderer, "MUSIC   :", "bahnschrift28", 230, 375, 0, 0, 0);
            boxRGBA(renderer, 375, 510, 373, 610, 0, 0, 0, 255);

            if (xm > 380 && xm < 440 && ym > 270 && ym < 319) {
                if (leftClick) {
                    soundManager.playSound("click");
                    if (soundsfx != 0) {
                        backsoundsfx = soundsfx;
                        soundsfx = 0;
                    } else {
                        soundsfx = backsoundsfx;
                    }
                    leftClick = false;
                }
            }
            if (xm > 470 && xm < 773 && ym > 290 && ym < 310) {
                entered[4] = true;
                if (adjustings) {
                    filledCircleRGBA(renderer, xm, 300, 9, 10, 20, 10, 255);
                    boxRGBA(renderer, xm, 296, 469, 304, 10, 20, 10, 255);
                    if (leftClick) {
                        soundManager.playSound("click");
                        leftClick = false;
                        adjustings = false;
                    }
                }
                if (leftClick) {
                    soundManager.playSound("click");
                    adjustings = true;
                    backsoundsfx = soundsfx;
                    soundsfx = (xm - 470) / 3;
                    leftClick = false;
                }
            } else {
                entered[4] = false;
                adjustings = false;
            }


            if (xm > 380 && xm < 440 && ym > 365 && ym < 414) {
                if (leftClick) {
                    soundManager.playSound("click");
                    if (soundmusic != 0) {
                        backsoundmusic = soundmusic;
                        soundmusic = 0;
                    } else
                        soundmusic = backsoundmusic;
                    leftClick = false;
                }
            }
            if (xm > 470 && xm < 773 && ym > 380 && ym < 400) {
                entered[5] = true;
                if (adjustingm) {
                    filledCircleRGBA(renderer, xm, 390, 9, 10, 20, 10, 255);
                    boxRGBA(renderer, xm, 386, 469, 394, 10, 20, 10, 255);
                    if (leftClick) {
                        soundManager.playSound("click");
                        leftClick = false;
                        adjustingm = false;
                    }
                }
                if (leftClick) {
                    soundManager.playSound("click");
                    adjustingm = true;
                    backsoundmusic = soundmusic;
                    soundmusic = (xm - 470) / 3;
                    leftClick = false;
                }
            } else {
                entered[5] = false;
                adjustingm = false;
            }
            if (xm > 390 && xm < 565 && ym > 520 && ym < 540) {
                entered[6] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[6] = false;
                    SOUNDMODE = 3;
                }
            } else { entered[6] = false; }

            if (xm > 390 && xm < 475 && ym > 550 && ym < 570) {
                entered[7] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[7] = false;
                    SOUNDMODE = 2;
                }
            } else { entered[7] = false; }

            if (xm > 390 && xm < 600 && ym > 580 && ym < 600) {
                entered[8] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    leftClick = false;
                    entered[8] = false;
                    SOUNDMODE = 1;
                }
            } else { entered[8] = false; }
        }//end change
        //start change
         else if (STATE == "highScores") {
            R = 74, G = 57, B = 101;
            textureManager.draw("hof", 0, 0, WIDTH, HEIGHT);
            skip = 25;
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }
            if (tab) STATE = "game";
            textRenderer.renderText(renderer, "HALL OF FAME", "bahnschrift32", WIDTH / 2 - 105, 130, 255, 255, 255);
            textRenderer.renderText(renderer, "USER NAME", "bahnschrift28", WIDTH / 5 - 60, 230, 255, 255, 255);
            textRenderer.renderText(renderer, "INFINITE", "bahnschrift28", WIDTH * 2 / 5, 230, 255, 255, 255);
            textRenderer.renderText(renderer, "TIME", "bahnschrift28", WIDTH * 3 / 5, 230, 255, 255, 255);
            textRenderer.renderText(renderer, "CASUAL", "bahnschrift28", WIDTH * 4 / 5 - 48, 230, 255, 255, 255);
            vector<USER_STRUCT> mock = usersData;
            sort(mock.begin(), mock.end(), [](const USER_STRUCT &user1, const USER_STRUCT &user2) {
                return user1.highestInfScore > user2.highestInfScore;
            });
            for (int i = 0; i < mock.size(); i++) {
                textRenderer.renderText(renderer, mock[i].username, "bahnschrift24", WIDTH / 5 - 60, 290 + 50 * i,
                                        255, 255,
                                        255);
                textRenderer.renderText(renderer, to_string(mock[i].highestInfScore), "bahnschrift24",
                                        WIDTH * 2 / 5,
                                        290 + 50 * i, 255, 255, 255);
                textRenderer.renderText(renderer, to_string(mock[i].highestTimeScore), "bahnschrift24",
                                        WIDTH * 3 / 5,
                                        290 + 50 * i, 255, 255, 255);
                textRenderer.renderText(renderer, to_string(mock[i].highestCasualScore), "bahnschrift24",
                                        WIDTH * 4 / 5 - 48, 290 + 50 * i, 255, 255, 255);

            }
            if (rightClick) {
                STATE = "mainMenu";
                rightClick = false;
            }

        }
         //end change
         else if (STATE == "modeSelection") {
            skip = 40;
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 2) {
                R = 6, G = 1, B = 41;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
            }
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }

            if (!entered[0]) { textureManager.draw("menuBack", xNG1 + 10, yNG2 - 100, 100, 100); }
            else {
                textureManager.draw("menuBackd", xNG1 + 10, yNG2 - 100, 100, 100);
            }
            if (!entered[1]) {
                textureManager.draw("normalMode", xNG2 - fsl - widthmode, yNG1 + fsl, widthmode, 3 * fsl);
            } else {
                textureManager.draw("normalMode", xNG2 - fsl - widthmode - 5, yNG1 + fsl - 5, widthmode + 10,
                                    3 * fsl + 10);
            }
            if (!entered[2]) {
                textureManager.draw("raceMode", xNG2 - fsl - widthmode, yNG1 + 5 * fsl, widthmode, 3 * fsl);
            } else {
                textureManager.draw("raceMode", xNG2 - fsl - widthmode - 5, yNG1 + 5 * fsl - 5, widthmode + 10,
                                    3 * fsl + 10);
            }
            if (!entered[3]) {
                textureManager.draw("infiniteMode", xNG2 - fsl - widthmode, yNG1 + 9 * fsl, widthmode, 3 * fsl);
            } else {
                textureManager.draw("infiniteMode", xNG2 - fsl - widthmode - 5, yNG1 + 9 * fsl - 5, widthmode + 10,
                                    3 * fsl + 10);
            }

            if (xm > xNG1 + 10 && xm < xNG1 + 110 && ym > yNG2 - 100 && ym < yNG2) {        //back
                entered[0] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[0] = false;
                    leftClick = false;
                    STATE = "mainMenu";

                }
            } else { entered[0] = false; }

            if (xm > xNG2 - fsl - widthmode && xm < xNG2 - fsl && ym > yNG1 + fsl &&
                ym < yNG1 + 4 * fsl) {        //normalmode
                entered[1] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[1] = false;
                    leftClick = false;
                    MODE = "casual";
                    STATE = "preGame";
                }
            } else { entered[1] = false; }

            if (xm > xNG2 - fsl - widthmode && xm < xNG2 - fsl && ym > yNG1 + 5 * fsl &&
                ym < yNG1 + 8 * fsl) {        //raceMode
                entered[2] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[2] = false;
                    leftClick = false;
                    MODE = "time";
                    STATE = "preGame";

                }
            } else { entered[2] = false; }

            if (xm > xNG2 - fsl - widthmode && xm < xNG2 - fsl && ym > yNG1 + 9 * fsl &&
                ym < yNG1 + 12 * fsl) {        //infiniteMode
                entered[3] = true;
                if (leftClick) {
                    soundManager.playSound("click");
                    entered[3] = false;
                    leftClick = false;
                    MODE = "inf";
                    STATE = "preGame";

                }
            } else { entered[3] = false; }
            // start change
        } else if (STATE == "getUsername") {
            textureManager.draw("hof", 0, 0, WIDTH, HEIGHT);
            skip = 25;
            R = 74, G = 57, B = 101;
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }
            if (newInputChar) {
                USER_NAME.push_back(inputChar);
            } else if (space) {
                USER_NAME.push_back(' ');
            } else if (backSpace) {
                if (!USER_NAME.empty())
                    USER_NAME.pop_back();
            } else if (enter) {
                bool userExists = false;
                for (int i = 0; i < usersData.size(); i++) {
                    if (USER_NAME == usersData[i].username) {
                        CURRENT_USER = &usersData[i];
                        userExists = true;
                    }
                }
                if (!userExists) {
                    usersData.push_back({USER_NAME, 0, 0, 0, 0, 0});
                    CURRENT_USER = &usersData[usersData.size() - 1];
                }
                printUserVector(usersData);
                STATE = "mainMenu";
            }
            textRenderer.renderText(renderer, "Enter your username :", "bahnschrift24", 150, 150, 255, 255,
                                    255);
            if (!USER_NAME.empty()) {
                textRenderer.renderText(renderer, USER_NAME, "bahnschrift24", 170, 180, 255, 255, 255);
            }
        }//end change
         else if (STATE == "CR") {
            if (THEME % 3 == 1) {
                R = 70, G = 41, B = 61;
                textureManager.draw("background1", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 2) {
                R = 6, G = 1, B = 41;
                textureManager.draw("background2", 0, 0, WIDTH, HEIGHT);
            }
            if (THEME % 3 == 0) {
                R = 59, G = 59, B = 59;
                textureManager.draw("background3", 0, 0, WIDTH, HEIGHT);
            }
            skip = 60;
            for (int count = 0; count < 5; count++) {
                boxRGBA(renderer, (WIDTH - 4 * skip - (3 - count) * 8), (3 * skip + 6 * count), (4 * skip - 8 * count),
                        (HEIGHT - 3 * skip - count * 6), R, G, B, (205 - 30 * count));
            }
            textRenderer.renderText(renderer, "Basic Programming 1402 - Sharif university", "bahnschrift20", 270, 230,
                                    0, 0,
                                    0);
            boxRGBA(renderer, 666, 258, 260, 260, 0, 0, 0, 255);
            textRenderer.renderText(renderer, "Dr.Araste  &  Dr.Vosooghi", "bahnschrift20", 358, 305, 0, 0, 0);
            textRenderer.renderText(renderer, "MohammadMehdi  Falahi", "bahnschrift16", 385, 355, 0, 0, 0);
            textRenderer.renderText(renderer, "Arshia  Noroozi", "bahnschrift16", 420, 375, 0, 0, 0);
            if (rightClick) {
                rightClick = false;
                STATE = "mainMenu";
            }
        }

        xNG1 = 4 * skip;
        xNG2 = WIDTH - 4 * skip - 24;
        yNG1 = 3 * skip;
        yNG2 = HEIGHT - 3 * skip;

        SDL_RenderPresent(renderer);
        SDL_Delay(DELAY);
        rightClick = false;
        leftClick = false;
        middleClick = false;
        newInputChar = false;
        backSpace = false;
        escape = false;
        space = false;
        enter = false;
        tab = false;
    }
    soundManager.playSound("byebye");

    // end the program
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
